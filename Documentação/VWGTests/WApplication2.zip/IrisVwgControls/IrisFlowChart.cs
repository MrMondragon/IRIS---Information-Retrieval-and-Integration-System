#region Using

using System;
using System.Data;
using System.Configuration;
using System.Web;
using Gizmox.WebGUI.Forms.Design;
using Gizmox.WebGUI.Common.Extensibility;
using System.ComponentModel;
using System.Drawing;
using Gizmox.WebGUI.Forms.Hosts;
using MindFusion.Diagramming.WebForms;
using System.Web.UI;
using Gizmox.WebGUI.Common.Interfaces;
using System.Web.UI.WebControls;
using System.Collections.Generic;

#endregion


namespace IrisVwgControls
{
  /// <summary>Encapsulates the methods and properties used for the ReportViewer control.</summary>
  [DesignTimeController("Gizmox.WebGUI.Forms.Design.PlaceHolderController, Gizmox.WebGUI.Forms.Design, Version=2.0.5701.0, Culture=neutral, PublicKeyToken=dd2a1fd4d120c769")]
  [ClientController("Gizmox.WebGUI.Client.Controllers.PlaceHolderController, Gizmox.WebGUI.Client, Version=2.0.5701.0, Culture=neutral, PublicKeyToken=0fb8f99bd6cd7e23")]
  [ToolboxItem(true)]
  public class IrisFlowChart : BaseIrisControlBox
  {

    public IrisFlowChart()
    {
      BackColor = Color.White;
      this.SetProperty("AllowRefLinks", false);
      this.SetProperty("AllowSplitArrows", true);
      this.SetProperty("AllowUnanchoredArrows", false);
      this.SetProperty("AntiAlias", System.Drawing.Drawing2D.SmoothingMode.AntiAlias);
      this.SetProperty("ArrowCascadeOrientation", Gizmox.WebGUI.Forms.Orientation.Horizontal);
      this.SetProperty("ArrowColor", Color.Black);
      this.SetProperty("ArrowCrossings", ArrowCrossings.Arcs);
      this.SetProperty("ArrowEndsMovable", false);
      this.SetProperty("ArrowHead", ArrowHead.BowArrow);
      this.SetProperty("ArrowHeadSize", 16);
      this.SetProperty("ArrowIntermSize", 16);
      this.SetProperty("ArrowSegments", (Int16)3);
      this.SetProperty("ArrowStyle", ArrowStyle.Cascading);
      this.SetProperty("Behavior", BehaviorType.CreateArrow);
      this.SetProperty("CrossingRadius", 4F);
      this.SetProperty("DisabledMnpColor", Color.Gray);
      this.SetProperty("GridColor", Color.FromArgb(224, 224, 224));
      this.SetProperty("GridSizeX", 6F);
      this.SetProperty("GridSizeY", 6F);
      this.SetProperty("GridStyle", GridStyle.Lines);
      this.SetProperty("ShowGrid", true);
      this.SetProperty("MeasureUnit", System.Drawing.GraphicsUnit.Pixel);
      this.SetProperty("DocExtents", new RectangleF(0, 0, this.Width * 10, this.Height * 10));
      this.SetProperty("InplaceEditFont", new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0));
      this.SetProperty("SelHandleSize", 8F);
      this.SetProperty("TableCaptionHeight", 23);
      this.SetProperty("TableColWidth", 30F);
      this.SetProperty("TableRowCount", 0);
      this.SetProperty("TableRowHeight", 17);
      this.SetProperty("ID", "flowChart");
      this.SetProperty("BackColor", Color.White);

      clientEvents = new Dictionary<string, string>();
      clientEvents["ArrowClicked"] = "";
      clientEvents["ArrowCreated"] = "";
      clientEvents["ArrowCreating"] = "";
      clientEvents["ArrowDblClicked"] = "";
      clientEvents["ArrowDeleted"] = "";
      clientEvents["ArrowDeleting"] = "";
      clientEvents["DocClicked"] = "";
      clientEvents["DocDblClicked"] = "";
      clientEvents["TableClicked"] = "";
      clientEvents["TableCreated"] = "";
      clientEvents["TableCreating"] = "";
      clientEvents["TableDblClicked"] = "";
      clientEvents["TableDeleted"] = "";
      clientEvents["TableDeleting"] = "";
      clientEvents["TableDeselected"] = "";

      clientEventArgs = new Dictionary<string, string>();

      clientEventArgs["ArrowClicked"] = "(arrow, mouseX, mouseY, button)";
      clientEventArgs["ArrowCreated"] = "(arrow)";
      clientEventArgs["ArrowCreating"] = "(arrow, mouseX, mouseY)";
      clientEventArgs["ArrowDblClicked"] = "(arrow, mouseX, mouseY, button)";
      clientEventArgs["ArrowDeleted"] = "(arrow)";
      clientEventArgs["ArrowDeleting"] = "(arrow)";
      clientEventArgs["DocClicked"] = "(mouseX, mouseY, button)";
      clientEventArgs["DocDblClicked"] = "(mouseX, mouseY, button)";
      clientEventArgs["TableClicked"] = "(table, mouseX, mouseY, button)";
      clientEventArgs["TableCreated"] = "(table)";
      clientEventArgs["TableCreating"] = "(table, mouseX, mouseY)";
      clientEventArgs["TableDblClicked"] = "(table, mouseX, mouseY, button)";
      clientEventArgs["TableDeleted"] = "(table)";
      clientEventArgs["TableDeleting"] = "(table)";
      clientEventArgs["TableDeselected"] = "(table)";
    }

    private Dictionary<string, string> clientEvents;
    private Dictionary<string, string> clientEventArgs;

    /// <summary>
    /// Stores the reporting state
    /// </summary>
    protected override void StoreState()
    {
      state = Surface.SaveToString(true);
    }

    private string state;

    /// <summary>
    /// Restores the reporting state
    /// </summary>
    protected override void RestoreState()
    {
      if (!string.IsNullOrEmpty(state))
        Surface.LoadFromString(state);
    }

    /// <summary>
    /// Return the hosted control type
    /// </summary>
    protected override Type HostedControlType
    {
      get
      {
        return typeof(FlowChart);
      }
    }

    protected FlowChart Surface
    {
      get
      {
        return HostedControl as FlowChart;
      }
    }

    [DefaultValue(typeof(Color), "#FFFFFF")]
    [Browsable(false)]
    public override Color BackColor
    {
      get
      {
        return Color.White;
      }
      set
      {

      }
    }

    public string ID
    {
      get
      {
        return Convert.ToString(GetProperty("ID"));
      }
      set
      {
        SetProperty("ID", value);
      }
    }

    protected override bool IsStatelessHostedControl
    {
      get
      {
        return base.IsStatelessHostedControl;
      }
    }

    #region Client events
    [Category("Client Scripts")]
    public string ArrowClicked
    {
      get { return clientEvents["ArrowClicked"]; }
      set { clientEvents["ArrowClicked"] = value; }
    }
    [Category("Client Scripts")]
    public string ArrowCreated
    {
      get { return clientEvents["ArrowCreated"]; }
      set { clientEvents["ArrowCreated"] = value; }
    }
    [Category("Client Scripts")]
    public string ArrowCreating
    {
      get { return clientEvents["ArrowCreating"]; }
      set { clientEvents["ArrowCreating"] = value; }
    }
    [Category("Client Scripts")]
    public string ArrowDblClicked
    {
      get { return clientEvents["ArrowDblClicked"]; }
      set { clientEvents["ArrowDblClicked"] = value; }
    }
    [Category("Client Scripts")]
    public string ArrowDeleted
    {
      get { return clientEvents["ArrowDeleted"]; }
      set { clientEvents["ArrowDeleted"] = value; }
    }
    [Category("Client Scripts")]
    public string ArrowDeleting
    {
      get { return clientEvents["ArrowDeleting"]; }
      set { clientEvents["ArrowDeleting"] = value; }
    }
    [Category("Client Scripts")]
    public string DocClicked
    {
      get { return clientEvents["DocClicked"]; }
      set { clientEvents["DocClicked"] = value; }
    }
    [Category("Client Scripts")]
    public string DocDblClicked
    {
      get { return clientEvents["DocDblClicked"]; }
      set { clientEvents["DocDblClicked"] = value; }
    }
    [Category("Client Scripts")]
    public string TableClicked
    {
      get { return clientEvents["TableClicked"]; }
      set { clientEvents["TableClicked"] = value; }
    }
    [Category("Client Scripts")]
    public string TableCreated
    {
      get { return clientEvents["TableCreated"]; }
      set { clientEvents["TableCreated"] = value; }
    }
    [Category("Client Scripts")]
    public string TableCreating
    {
      get { return clientEvents["TableCreating"]; }
      set { clientEvents["TableCreating"] = value; }
    }
    [Category("Client Scripts")]
    public string TableDblClicked
    {
      get { return clientEvents["TableDblClicked"]; }
      set { clientEvents["TableDblClicked"] = value; }
    }
    [Category("Client Scripts")]
    public string TableDeleted
    {
      get { return clientEvents["TableDeleted"]; }
      set { clientEvents["TableDeleted"] = value; }
    }
    [Category("Client Scripts")]
    public string TableDeleting
    {
      get { return clientEvents["TableDeleting"]; }
      set { clientEvents["TableDeleting"] = value; }
    }
    [Category("Client Scripts")]
    public string TableDeselected
    {
      get { return clientEvents["TableDeselected"]; }
      set { clientEvents["TableDeselected"] = value; }
    }

    protected override void AddCustomAttributes(ref Page page, ref WebControl control)
    {
      Type type = this.GetType();
      foreach (KeyValuePair<string, string> clientEvent in clientEvents)
      {
        if (!string.IsNullOrEmpty(clientEvent.Value))
        {
          //define o nome da fun��o utilizando o ID do componente e o GUID do host
          string functionName = ID + this.Guid + "_on" + clientEvent.Key;
          //define o corpo da fun��o
          string script = "<script type=text/javascript> \r\n function ";
          script += functionName + clientEventArgs[clientEvent.Key];
          script += "\r\n{\r\n" + clientEvent.Value + "\r\n}\r\n </script>";
          //registra o script na p�gina
          page.ClientScript.RegisterClientScriptBlock(type, functionName, script);
          //seta a propriedade no controle
          control.Attributes.Add(clientEvent.Key, functionName);
        }
      }
      base.AddCustomAttributes(ref page, ref control);
    }
    #endregion

    public void TestScript()
    {
      RegisterSelf();
      string code = string.Format(@"
flowChart = GetFlowChart('{0}').getFlowChart();
flowChart.createTable(7, 7, 100, 100);", this.Guid);
      this.InvokeMethodWithId("IrisFlowChart_Eval", code);
      UnRegisterSelf();
    }


  }
}
