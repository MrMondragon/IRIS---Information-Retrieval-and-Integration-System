﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlbinoHorse.Model
{
    public class UmlTypeMember
    {
        public string Name { get; set; }
    }
}
