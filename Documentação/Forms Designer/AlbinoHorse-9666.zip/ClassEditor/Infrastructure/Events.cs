﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlbinoHorse.Infrastructure
{
    public delegate void Action();

    public delegate void ShapeCancelHandler(object sender, ShapeCancelEventArgs args);
    
}
