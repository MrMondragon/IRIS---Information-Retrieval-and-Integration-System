﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ATSMS")> 
<Assembly: AssemblyDescription("AT Command Communication Software")> 
<Assembly: AssemblyCompany("ClickMore (M) Sdn. Bhd.")> 
<Assembly: AssemblyProduct("ATCOMM")> 
<Assembly: AssemblyCopyright("Copyright ©  2006")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("91df7770-a531-4a72-bfd9-20e8746bed3d")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.5")> 
<Assembly: AssemblyFileVersion("1.0.0.5")> 
