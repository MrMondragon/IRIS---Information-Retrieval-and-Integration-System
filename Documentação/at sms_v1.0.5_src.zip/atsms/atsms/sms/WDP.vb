Imports System


Namespace SMS

    ' <summary>
    ' Well known values used when generating a WDP (Wireless Datagram Protocol) header
    ' </summary>
    Public Class WDP
        Public Const INFORMATIONELEMENT_IDENTIFIER_APPLICATIONPORT As Byte = &H5
    End Class 'WDP

End Namespace