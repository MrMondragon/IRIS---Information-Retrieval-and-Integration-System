﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("SimpleDemo")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("SimpleDemo")>
<Assembly: AssemblyCopyright("Copyright ©  2006")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>
