using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using Iris.BuilderPlugin.Properties;
using Iris.Designer.BuildSupport;

namespace Iris.BuilderPlugin
{
  public class WebServiceBuilderPlugin : BaseAssemblyBuilder
  {
    protected override string GetHint()
    {
      return "Compilar Web Service";
    }

    protected override Image GetImage()
    {
      return Resources.BuildWS;
    }

    public override void DoExecute()
    {
      BuildAssembly(BuildType.WebService);
    }
  }
}
