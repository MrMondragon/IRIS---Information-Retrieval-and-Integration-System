using System;
using System.Collections.Generic;
using System.Text;
using Iris.Designer.BuildSupport;
using Iris.BuilderPlugin.Properties;
using System.Drawing;

namespace Iris.BuilderPlugin
{
  public class ExeBuilderPlugin : BaseAssemblyBuilder
  {
    protected override string GetHint()
    {
      return "Compilar Execut�vel";
    }

    protected override Image GetImage()
    {
      return Resources.BuildExe;
    }

    public override void DoExecute()
    {
      BuildAssembly(BuildType.Executable);
    }
  }
}
