using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.Designer.BuildSupport
{
  internal enum BuildType
  {
    Assembly,
    Executable,
    WebService,
    Plugin
  }
}
