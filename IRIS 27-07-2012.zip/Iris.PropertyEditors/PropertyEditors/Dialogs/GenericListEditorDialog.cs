﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Databridge.Interfaces.BaseEditors;

namespace Iris.PropertyEditors.PropertyEditors.Dialogs
{
  public partial class GenericListEditorDialog : BaseDialog
  {
    public GenericListEditorDialog()
    {
      InitializeComponent();
    }

    private void GenericListEditorDialog_Load(object sender, EventArgs e)
    {

    }
  }
}
