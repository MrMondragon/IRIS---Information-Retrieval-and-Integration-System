using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Iris.PropertyEditors.Dialogs;
using Databridge.Interfaces.BaseEditors;

namespace Iris.PropertyEditors.PropertyEditors.Dialogs
{
  public partial class StringListEditorDialog : BaseDialog
  {
    public StringListEditorDialog()
    {
      InitializeComponent();
    }

    public List<String> GetStringList()
    {
      return control.GetStringList();
    }

    public void SetStringList(List<String> stringList)
    {
      control.SetStringList(stringList);
    }
  }
}