﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iris.DynamicsServices
{
  public enum OperationType
  {
    Update,
    Insert
  }
}
