using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.Runtime.Model
{
  [Serializable]
  public enum AlignType
  {
    Left,
    Right,
  }
}
