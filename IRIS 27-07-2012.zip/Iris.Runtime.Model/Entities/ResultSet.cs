using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Iris.Runtime.Core.Connections;
using System.Data.Odbc;
using System.Data.Common;
using Iris.Runtime.Core.Expressions;
using Iris.Runtime.Core;
using Iris.Runtime.Model.BaseObjects;
using System.ComponentModel;
using System.Drawing.Design;
using Iris.PropertyEditors;
using Iris.Interfaces;
using Iris.Runtime.Model.PropertyEditors;
using Iris.Runtime.Core.ParserEngine.ParserObjects;
using System.ComponentModel.Design;
using Databridge.Engine.Data;
using Databridge.Interfaces;

namespace Iris.Runtime.Model.Entities
{
  [Serializable]
  public class ResultSet : BaseResultSet, IResultSet, IScriptedObject, IEntity, IOperation
  {
    public ResultSet(string name, Structure structure, DynConnection connection, String sql)
      : this(name, structure)
    {
      Sql = sql;
      this.Connection = connection;
    }

    public ResultSet(string name, Structure structure)
    {
      this.Structure = structure;
      this.Name = name;
      Structure.ResultSets.Add(this);
    }


    [DisplayName("Select"), Category("SQL")]
    [Editor(typeof(ScriptEditor), typeof(UITypeEditor))]
    public override string Sql
    {
      get
      {
        return base.Sql;
      }
      set
      {
        base.Sql = value;
      }
    }


    [DisplayName("Nome"), Category("Design")]
    public override string Name
    {
      get { return name; }
      set
      {
        if (name != value)
        {
          base.OnBeforeNameChange();
          name = Structure.GetValidName(value);
          base.OnAfterNameChange();
        }
      }
    }



    [ReadOnly(true), Editor(typeof(TableEditor), typeof(UITypeEditor))]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public override DataTable Table
    {
      get
      {
        if ((base.Table == null) && (this.Schema != null))
          this.Schema.RefreshResultSets(this);

        return base.Table;
      }
      set
      {
        base.Table = value;

        if (table != null)
        {
          string tableName = table.TableName;
          if(!Structure.Dataset.Tables.Contains(tableName))
          Structure.Dataset.Tables.Add(table);

        }


      }
    }



    /// <summary>
    /// Gets the connection.
    /// </summary>
    /// <value>The connection.</value>
    [Editor(typeof(ConnectionSelectorEditor), typeof(UITypeEditor))]
    public new DynConnection Connection
    {
      get
      {
        return (DynConnection)base.Connection;
      }
      set
      {
        base.Connection = value;
      }
    }


    [DisplayName("SQL Insert"), Category("SQL")]
    [Editor(typeof(ResultSetInsertEditor), typeof(UITypeEditor))]
    public override string InsertCommand
    {
      get
      {
        return base.InsertCommand;
      }
      set
      {
        base.InsertCommand = value;
      }
    }

    /// <value>The insert command.</value>
    [DisplayName("SQL Delete"), Category("SQL")]
    [Editor(typeof(ResultSetDeleteEditor), typeof(UITypeEditor))]
    public override string DeleteCommand
    {
      get
      {
        return base.DeleteCommand;
      }
      set
      {
        base.DeleteCommand = value;
      }
    }



    [DisplayName("SQL Update"), Category("SQL")]
    [Editor(typeof(ResultSetUpdateEditor), typeof(UITypeEditor))]
    public override string UpdateCommand
    {
      get
      {
        return base.UpdateCommand;
      }
      set
      {
        base.UpdateCommand = value;
      }
    }





    [Editor(typeof(PKEditor), typeof(UITypeEditor))]
    [DisplayName("Chave Prim�ria")]
    public override List<DataColumn> PrimaryKey
    {
      get
      {
        return base.PrimaryKey;
      }
      set
      {
        base.PrimaryKey = value;
      }
    }

    [DisplayName("Rela��es Mestre"), Category("Relations")]
    [Editor(typeof(CollectionEditor), typeof(UITypeEditor))]
    public DataRelationCollection ParentRelations
    {
      get
      {
        if (Table != null)
          return Table.ParentRelations;
        else
          return null;
      }
    }

    [DisplayName("Rela��es Detalhe"), Category("Relations")]
    [Editor(typeof(CollectionEditor), typeof(UITypeEditor))]
    public DataRelationCollection ChildRelations
    {
      get
      {
        if (Table != null)
          return Table.ChildRelations;
        else
          return null;
      }
    }

    private bool externalParam;
    [Browsable(true), DisplayName("RS Externo"), Category("Design")]
    public bool ExternalParam
    {
      get
      {
        return externalParam;
      }
      set
      {
        externalParam = value;
      }
    }

    private SchemaEntity schema;
    [Browsable(false)]
    internal SchemaEntity Schema
    {
      get { return schema; }
      set { schema = value; }
    }

    [Browsable(false)]
    public Structure Structure { get; set; }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public override Databridge.Engine.ExecutionContext Context
    {
      get
      {
        return Structure.GetContext();
      }
      set
      {
      }
    }

    [DisplayName("Descri��o"), Category("Design")]
    public string Description
    {
      get;
      set;
    }

    #region IResultSet Members


    IStructure IResultSet.Structure
    {
      get
      {
        return Structure;
      }
    }

    #endregion

    #region IScriptedObject Members

    [Browsable(false)]
    public string Script
    {
      get
      {
        return Sql;
      }
      set
      {
        Sql = value;
      }
    }

    [Browsable(false)]
    public string Language
    {
      get { return "SQL"; }
    }



    #endregion



    #region IConnectedObject Members

    [Browsable(false)]
    IDataConnection IConnectedObject.Connection
    {
      get
      {
        return Connection;
      }
      set
      {
        Connection = (DynConnection)value;
      }
    }

    #endregion

    #region IOperation Members



    void IOperation.Execute()
    {
      this.Fill();
    }

    [Browsable(false)]
    bool IOperation.IgnoreFailure
    {
      get
      {
        return true;
      }
      set
      {
      }
    }


    [Browsable(false)]
    IOperation IOperation.OnFailure
    {
      get
      {
        return null;
      }
      set
      {
      }
    }

    [Browsable(false)]
    IOperation IOperation.OnSuccess
    {
      get
      {
        return null;
      }
      set
      {
      }
    }

    [Browsable(false)]
    IEntity IOperation.Result
    {
      get
      {
        return this;
      }
      set
      {
      }
    }

    string IOperation.ToString()
    {
      return this.Name;
    }

    [Browsable(false)]
    object IOperation.Value
    {
      get { return View; }
    }

    [Browsable(false)]
    IEntity IOperation.EntityValue
    {
      get { return this; }
    }


    [Browsable(false)]
    IStructure IOperation.Structure
    {
      get { return Structure; }
    }

    [Browsable(false)]
    IExecutionContext IScriptedObject.Context
    {
      get { return Structure.GetContext(); }
    }
    #endregion

    [Browsable(false)]
    public string Notes { get; set; }
  }
}
