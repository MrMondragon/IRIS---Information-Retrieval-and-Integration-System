using System;
using System.Collections.Generic;
using System.Text;
using Iris.Runtime.Model.BaseObjects;
using Iris.Runtime.Core.Connections;
using System.ComponentModel;
using System.Drawing.Design;
using Iris.PropertyEditors;
using Iris.Interfaces;
using Iris.Runtime.Model.PropertyEditors;
using Iris.PropertyEditors.PropertyEditors;

namespace Iris.Runtime.Model.Entities
{
  [Serializable]
  public class ScalarVar : Entity, IScalarVar
  {
    public ScalarVar(string aName, Structure aStructure)
      : base(aName, aStructure)
    {
      if(aStructure != null)
        aStructure.ScalarVars.Add(this);

      persistValue = false;
    }

    private bool persistValue;
     [DisplayName("Persistir"), Category("Vari�vel"), Description("Indica se o valor da vari�vel deve ser gravado junto com o projeto, ou se ele deve ser limpo quando o projeto for gravado/resetado")]
    public bool PersistValue
    {
      get { return persistValue; }
      set { persistValue = value; }
    }

    public override void Reset()
    {
      base.Reset();
      if (!PersistValue)
      {
        rawValue = null;
        DataType = typeof(string);
      }
    }

    protected Object rawValue;
    [Editor(typeof(ScalarVarValueEditor), typeof(UITypeEditor))]
    [DisplayName("Valor"), Category("Vari�vel"), Description("Valor da Vari�vel")]
    public virtual Object RawValue
    {
      get { return this.rawValue; }
      set 
      {
        if (rawValue != value)
        {
          if (!ValidateValue(value))
            throw new Exception("Valor Inv�lido");
          else
          {
            this.rawValue = value;
            if ((value != null) && (value.GetType() != DataType))
              DataType = value.GetType();
          }
        }
      }
    }

    private bool ValidateValue(object value)
    {
      bool valid = true;
      if (ValidValues.Count > 0)
      {
        valid = false;
        string stValue = Convert.ToString(value);
        for (int i = 0; i < ValidValues.Count; i++)
        {
          string stValid = ValidValues[i];
          if (stValue == stValid)
          {
            valid = true;
            break;
          }
        }        
      }

      return valid;
    }

    [Browsable(false)]
    public override object Value
    {
      get { return RawValue; }
    }

    [Browsable(true), Description("Tipo de dado do valor da Vari�vel")]
    public override Type DataType
    {
      get
      {
        return base.DataType;
      }
      set
      {
        base.DataType = value;
      }
    }

    [Browsable(true), DisplayName("Par�metro"), Category("Design")]
    public override bool ExternalParam
    {
      get
      {
        return base.ExternalParam;
      }
      set
      {
        base.ExternalParam = value;
      }
    }

    private List<string> validValues;
    [Editor(typeof(ScalarValidValuesEditor), typeof(UITypeEditor))]
    [DisplayName("Valores V�lidos"), Category("Vari�vel"), Description("Lista de valores v�lidos para a vari�vel")]
    public List<string> ValidValues
    {
      get 
      {
        if (validValues == null)
          validValues = new List<string>();

        return validValues; 
      }
      set 
      { 
        validValues = value;
        RawValue = null;
      }
    }

    protected override IEntity doExecute()
    {
      return this;
    }

  }
}
