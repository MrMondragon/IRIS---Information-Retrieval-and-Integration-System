using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.Runtime.Model.DisignSuport
{
  [AttributeUsage(AttributeTargets.Assembly)]
  public class OperationPluginAssembly: Attribute
  {
  }
}
