using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.Runtime.Model.DisignSuport
{
  public enum QueryType
  {
    Comando,
    Registros,
    Valor_Escalar
  }
}
