﻿using System;
using System.Data;
using System.Collections.Generic;

namespace Databridge.Interfaces
{
  public interface IExecutionContext
  {
    DataSet Dataset { get; set; }
    DataTable GetTable(string tableName);
    Dictionary<string, object> Objects { get; set; }
    Dictionary<string, object> Parameters { get; set; }
    Dictionary<string, object> Variables { get; set; }
  }
}
