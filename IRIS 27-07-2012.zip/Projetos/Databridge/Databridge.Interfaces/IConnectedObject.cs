using System;
using System.Collections.Generic;
using System.Text;

namespace Databridge.Interfaces
{
  public interface  IConnectedObject
  {
    IDataConnection Connection { get;set; }
  }
} 
