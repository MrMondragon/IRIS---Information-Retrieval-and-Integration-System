﻿using System;
namespace Databridge.Interfaces
{
  public interface IBaseResultSet
  {
    void Apply(System.Data.DataRow[] rows);
    void Clear();
    IDataConnection Connection { get; set; }
    IExecutionContext Context { get; set; }
    bool ContinueUpdateOnError { get; set; }
    string DeleteCommand { get; set; }
    string[] Errors { get; }
    void Fill();
    bool GenDelete { get; set; }
    bool GenInsert { get; set; }
    bool GenUpdate { get; set; }
    bool HasErrors { get; }
    bool HasView();
    bool InMemory { get; set; }
    string InsertCommand { get; set; }
    string Name { get; set; }
    System.Collections.Generic.List<System.Data.DataColumn> PrimaryKey { get; set; }
    int RecCount { get; }
    void SetTable(System.Data.DataTable table);
    string Sql { get; set; }
    System.Data.DataTable Table { get; set; }
    int TimeOut { get; set; }
    int UpdateBatchSize { get; set; }
    string UpdateCommand { get; set; }
    System.Data.DataView View { get; set; }
  }
}
