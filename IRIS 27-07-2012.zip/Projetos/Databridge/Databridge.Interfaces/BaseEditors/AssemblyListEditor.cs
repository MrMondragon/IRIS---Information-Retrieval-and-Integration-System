using System;
using System.Collections.Generic;
using System.Text;
using Databridge.Interfaces;
using Databridge.Interfaces.BaseEditors;

namespace Databridge.Interfaces
{
  public class AssemblyListEditor : BaseDialogEditor<IAssemblyUser>
  {
    protected override object GetValue(IAssemblyUser Instance)
    {
      AssemblyListEditorDialog dlg = new AssemblyListEditorDialog(Instance.Assemblies);
      if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
      {
        Instance.Assemblies = dlg.GetAssemblies();
      }
      return Instance.Assemblies;
    }
  }
}
