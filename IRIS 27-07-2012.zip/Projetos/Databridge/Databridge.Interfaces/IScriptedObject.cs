using System;
using System.Collections.Generic;
using System.Text;

namespace Databridge.Interfaces
{
  public interface IScriptedObject
  {
    String Script { get; set;}
    String Language { get;}
    IExecutionContext Context { get; }
  
  }
}
