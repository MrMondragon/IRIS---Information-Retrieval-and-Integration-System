using System;
using System.Collections.Generic;
using System.Text;

namespace Databridge.Interfaces
{
  public interface IClearable
  {
    void Clear();
  }
}
