﻿using System;
using System.Net;
namespace Databridge.Interfaces
{
  public interface ICredentialUser
  {
    NetworkCredential Credentials { get; set; }
  }
}
