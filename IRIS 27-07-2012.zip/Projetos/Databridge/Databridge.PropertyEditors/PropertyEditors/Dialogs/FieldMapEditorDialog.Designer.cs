namespace Databridge.PropertyEditors.Dialogs
{
  partial class FieldMapEditorDialog
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FieldMapEditorDialog));
      this.surface = new MindFusion.Diagramming.WinForms.FlowChart();
      this.btnClear = new System.Windows.Forms.Button();
      this.btnAutoLink = new System.Windows.Forms.Button();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // btnOk
      // 
      this.btnOk.TabIndex = 0;
      // 
      // btnCancel
      // 
      this.btnCancel.TabIndex = 1;
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.btnClear);
      this.panel1.Controls.Add(this.btnAutoLink);
      this.panel1.Location = new System.Drawing.Point(0, 418);
      this.panel1.Size = new System.Drawing.Size(436, 30);
      this.panel1.Controls.SetChildIndex(this.btnAutoLink, 0);
      this.panel1.Controls.SetChildIndex(this.btnClear, 0);
      this.panel1.Controls.SetChildIndex(this.btnCancel, 0);
      this.panel1.Controls.SetChildIndex(this.btnOk, 0);
      // 
      // surface
      // 
      this.surface.AllowRefLinks = false;
      this.surface.AntiAlias = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
      this.surface.ArrowBase = MindFusion.Diagramming.WinForms.ArrowHead.RevTriangle;
      this.surface.ArrowBaseSize = 10F;
      this.surface.ArrowCascadeOrientation = MindFusion.Diagramming.WinForms.Orientation.Horizontal;
      this.surface.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
      this.surface.ArrowEndsMovable = false;
      this.surface.ArrowHead = MindFusion.Diagramming.WinForms.ArrowHead.BowArrow;
      this.surface.ArrowHeadSize = 16F;
      this.surface.ArrowIntermSize = 16F;
      this.surface.ArrowSegments = ((short)(3));
      this.surface.ArrowStyle = MindFusion.Diagramming.WinForms.ArrowStyle.Cascading;
      this.surface.Behavior = MindFusion.Diagramming.WinForms.BehaviorType.CreateArrow;
      this.surface.CellFrameStyle = MindFusion.Diagramming.WinForms.CellFrameStyle.Simple;
      this.surface.DocExtents = ((System.Drawing.RectangleF)(resources.GetObject("surface.DocExtents")));
      this.surface.Dock = System.Windows.Forms.DockStyle.Fill;
      this.surface.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.surface.GridSizeX = 8F;
      this.surface.GridSizeY = 8F;
      this.surface.GridStyle = MindFusion.Diagramming.WinForms.GridStyle.Lines;
      this.surface.InplaceEditFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.surface.Location = new System.Drawing.Point(0, 0);
      this.surface.MeasureUnit = System.Drawing.GraphicsUnit.Pixel;
      this.surface.Name = "surface";
      this.surface.RoutingOptions.GridSize = 16F;
      this.surface.RoutingOptions.NodeVicinitySize = 48F;
      this.surface.SelHandleSize = 6F;
      this.surface.ShadowColor = System.Drawing.SystemColors.ControlDarkDark;
      this.surface.Size = new System.Drawing.Size(436, 418);
      this.surface.SnapToAnchor = MindFusion.Diagramming.WinForms.SnapToAnchor.OnCreateOrModify;
      this.surface.TabIndex = 2;
      this.surface.TableCaptionHeight = 20F;
      this.surface.TableColWidth = 150F;
      this.surface.TableHandlesStyle = MindFusion.Diagramming.WinForms.HandlesStyle.SquareHandles2;
      this.surface.TableRowCount = 0;
      this.surface.TableRowHeight = 18F;
      this.surface.TablesScrollable = true;
      this.surface.ArrowCreated += new MindFusion.Diagramming.WinForms.ArrowEvent(this.surface_ArrowCreated);
      // 
      // btnClear
      // 
      this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnClear.Location = new System.Drawing.Point(358, 4);
      this.btnClear.Name = "btnClear";
      this.btnClear.Size = new System.Drawing.Size(75, 23);
      this.btnClear.TabIndex = 2;
      this.btnClear.Text = "Limpar";
      this.btnClear.UseVisualStyleBackColor = true;
      this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
      // 
      // btnAutoLink
      // 
      this.btnAutoLink.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnAutoLink.Location = new System.Drawing.Point(256, 3);
      this.btnAutoLink.Name = "btnAutoLink";
      this.btnAutoLink.Size = new System.Drawing.Size(96, 23);
      this.btnAutoLink.TabIndex = 3;
      this.btnAutoLink.Text = "Corresp. Autom.";
      this.btnAutoLink.UseVisualStyleBackColor = true;
      this.btnAutoLink.Click += new System.EventHandler(this.btnAutoLink_Click);
      // 
      // FieldMapEditorDialog
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(436, 448);
      this.ControlBox = true;
      this.Controls.Add(this.surface);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
      this.Name = "FieldMapEditorDialog";
      this.Text = "Correspond�ncias";
      this.Controls.SetChildIndex(this.panel1, 0);
      this.Controls.SetChildIndex(this.surface, 0);
      this.panel1.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private MindFusion.Diagramming.WinForms.FlowChart surface;
    private System.Windows.Forms.Button btnClear;
    private System.Windows.Forms.Button btnAutoLink;
  }
}