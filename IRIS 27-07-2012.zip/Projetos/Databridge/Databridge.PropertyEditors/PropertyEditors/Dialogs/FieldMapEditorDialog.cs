using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MindFusion.Diagramming.WinForms;
using Iris.Runtime.Core;
using Databridge.Interfaces.BaseEditors;

namespace Databridge.PropertyEditors.Dialogs
{
  public partial class FieldMapEditorDialog : BaseDialog
  {
    public FieldMapEditorDialog()
    {
      InitializeComponent();
      surface.BackColor = Color.White;
      surface.ArrowBrush = new MindFusion.Drawing.SolidBrush(Color.White);
      surface.TableBrush = new MindFusion.Drawing.SolidBrush(SystemColors.Control);
    }


    public List<KeyValuePair<string, string>> GetFieldMap()
    {
      List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
      List<string> uniqueList = new List<string>();
      foreach (Arrow arrow in surface.Arrows)
      {
        int orig = arrow.OrgnIndex;
        int dest = arrow.DestIndex;
        string origStr = sourceTable[1, orig].Text;
        string destStr = destTable[1, dest].Text;
        string uniqueKey = origStr + "-" + destStr;

        if (!uniqueList.Contains(uniqueKey))
        {
          KeyValuePair<string, string> kvi = new KeyValuePair<string, string>(origStr, destStr);
          list.Add(kvi);
          uniqueList.Add(uniqueKey);
        }
      }
      return list;
    }

    private DataTable source;
    private DataTable destination;

    public FieldMapEditorDialog(DataTable _source, DataTable _destination, List<KeyValuePair<string, string>> fieldMap)
      : this()
    {
      sourceTable = CreateTable(_source, true);
      destTable = CreateTable(_destination, false);
      
      source = _source;
      destination = _destination;

      if (fieldMap != null)
      {
        foreach (KeyValuePair<string, string> kvi in fieldMap)
        {
          CreateArrow(kvi);
        }
      }
      surface.Selection.Clear();
    }

    private void CreateArrow(KeyValuePair<string, string> kvi)
    {
      int idxOrigem = GetFieldIndex(sourceTable, kvi.Key);
      int idxDestino = GetFieldIndex(destTable, kvi.Value);
      surface.CreateArrow(sourceTable, idxOrigem, destTable, idxDestino);
    }

    private int GetFieldIndex(Table table, string p)
    {
      for (int i = 0; i < table.Rows.Count; i++)
			{
        if (table[1, i].Text.ToLower() == p.ToLower())
          return i;
      }
      return -1;
    }


    private Table sourceTable;
    private Table destTable;

    private Table CreateTable(DataTable dataTable, bool isSource)
    {

      int tableHeight = (int)((surface.TableCaptionHeight * 2) + ((dataTable.Columns.Count) * surface.TableRowHeight));
      Table table = surface.CreateTable(0, 0, 112, tableHeight);
      table.Caption = dataTable.TableName;

      foreach (DataColumn column in dataTable.Columns)
      {
        int idx = table.AddRow();
        table[1, idx].Brush = new MindFusion.Drawing.SolidBrush(Color.White);
        table[1, idx].Text = column.ColumnName;
        table[0, idx].Text = "  ";
      }

      table.ResizeToFitText(false);


      float y = (surface.Height / 2) - (tableHeight / 2);
      
      if (y < 10)
        y = 10;

      float x;

      if (isSource)
      {
        table.FillColor = SystemColors.ControlLight;
        x = 40;
      }
      else
      {
        table.FillColor = SystemColors.Control;
        x = surface.Width - table.BoundingRect.Width - 40;
      }
      table.Move(x, y);
      return table;
    }

    private void surface_ArrowCreated(object sender, ArrowEventArgs e)
    {
      Arrow arrow = e.Arrow;
      if (arrow.Origin == destTable)
      {
        int origIdx = arrow.OrgnIndex;
        int destIdx = arrow.DestIndex;
        surface.DeleteObject(arrow);
        arrow = surface.CreateArrow(sourceTable, destIdx, destTable, origIdx);
      }

    }

    private void btnClear_Click(object sender, EventArgs e)
    {
      while (surface.Arrows.Count > 0)
        surface.DeleteObject(surface.Arrows[0]);
    }

    private void btnAutoLink_Click(object sender, EventArgs e)
    {
      List<string> campos = new List<string>();
      List<KeyValuePair<string, string>> map = GetFieldMap();
      List<string> uniqueList = new List<string>();
      for (int i = 0; i < map.Count; i++)
      {
        uniqueList.Add(map[i].Key.ToLower() + "-" + map[i].Value.ToLower());
      }

      for (int i = 0; i < source.Columns.Count; i++)
      {
        for (int j = 0; j < destination.Columns.Count; j++)
        {
          string orig = source.Columns[i].ColumnName.ToLower();
          string dest = destination.Columns[j].ColumnName.ToLower();
          string uniqueKey = orig+"-"+dest;
          if (orig == dest) 
          {
            if (!uniqueList.Contains(uniqueKey))
            {
              campos.Add(source.Columns[i].ColumnName);
            }
            break;
          }
        }
      }

      foreach (string fieldName in campos)
      {
        KeyValuePair<string, string> kvi = new KeyValuePair<string, string>(fieldName, fieldName);
        CreateArrow(kvi);
      }
    }
  }
}