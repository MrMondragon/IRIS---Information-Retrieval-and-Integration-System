using System;
using System.Collections.Generic;
using System.Text;
using Databridge.PropertyEditors.Dialogs;
using Databridge.PropertyEditors;
using System.Windows.Forms;
using Databridge.Interfaces;
using Databridge.Interfaces.BaseEditors;

namespace Databridge.PropertyEditors
{
  public class ColunaDefValueEditor: BaseDialogEditor<IColuna>
  {
    protected override object GetValue(IColuna Instance)
    {
      ObjectEditorDialog dlg = new ObjectEditorDialog();
      dlg.Value = Instance.DefaultValue;
      if (dlg.ShowDialog() == DialogResult.OK)
      {
        Instance.DefaultValue = dlg.Value;
      }
      return Instance.DefaultValue;
    }
  }
}
