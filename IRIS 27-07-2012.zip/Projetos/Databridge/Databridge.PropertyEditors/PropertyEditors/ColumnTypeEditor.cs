using System;
using System.Collections.Generic;
using System.Text;
using Databridge.PropertyEditors;
using Databridge.Interfaces.BaseEditors;

namespace Databridge.PropertyEditors
{
  public class ColumnTypeEditor: BaseListEditor<string>
  {
    protected override List<string> GetItems(object obj)
    {
      string[] types = new string[] {"String","Int16","Int32","Int64","UInt16","UInt32","UInt64",
        "Byte","SByte","Decimal","Double","Single","DateTime","Boolean"};

      return new List<string>(types);

    }

  }
}
