﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Data;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Services.Utility;

namespace CRMFramework2011
{
  [Serializable]
  public class ServiceManager : IDisposable
  {
    public ServiceManager(string organization)
      : this(false, organization)
    {

    }

    public ServiceManager(bool online, string organization)
    {
      this.Online = online;
      Organization = organization;

      if (online)
      {
        this.serverAddress = string.Format("https://{0}.api.crm.dynamics.com/XrmServices/2011/Organization.svc", organization);
        this.orgURI = new Uri(this.serverAddress);

        this.credentials = new ClientCredentials();
        this.credentials.UserName.UserName = Settings.ServiceUser;
        this.credentials.UserName.Password = Settings.ServicePassword;
      }
      else
      {
        this.credentials = new ClientCredentials();
        credentials.Windows.ClientCredential = Settings.Credentials;
        this.serverAddress = Settings.ServiceAddress;
        this.orgURI = new Uri(Settings.ServiceAddress);
      }

    }

    public ServiceManager(string organization, bool useHttps)
      : this(organization)
    {
      if (useHttps)
        this.serverAddress = serverAddress.Replace("http:", "https:");
    }

    public ServiceManager(string organization, ClientCredentials credentials, string serverAddress)
    {
      this.Organization = organization;
      this.credentials = credentials;
      this.serverAddress = string.Format(@"http://{0}/{1}/XRMServices/2011/Organization.svc", serverAddress, organization);
      this.orgURI = new Uri(this.serverAddress);
      this.deviceCredentials = DeviceIdManager.LoadOrRegisterDevice();
    }

    public ServiceManager(string organization, ClientCredentials credentials, string serverAddress, bool useHttps)
      : this(organization, credentials, serverAddress)
    {
      if (useHttps)
        this.ServerAddress = serverAddress.Replace("http:", "https:");
    }

    private string Organization;

    [NonSerialized]
    private ClientCredentials credentials;

    public ClientCredentials Credentials
    {
      get { return credentials; }
    }

    [NonSerialized]
    private ClientCredentials deviceCredentials;

    public ClientCredentials DeviceCredentials
    {
      get
      {
        if ((deviceCredentials == null) && (Online))
          deviceCredentials = DeviceIdManager.LoadOrRegisterDevice();
        return deviceCredentials;
      }
    }

    public bool Online { get; set; }

    [NonSerialized]
    private Uri orgURI;

    private string serverAddress;

    public string ServerAddress
    {
      get
      {
        if (Settings.UseHttps)
          return serverAddress.Replace("http:", "https:");
        else
          return serverAddress;
      }
      set
      {
        lock (this)
        {
          serverAddress = value;
          this.orgURI = new Uri(this.serverAddress);
          serviceProxy = null;
        }
      }
    }

    [NonSerialized]
    private OrganizationServiceProxy serviceProxy;

    public OrganizationServiceProxy ServiceProxy
    {
      get
      {
        if (serviceProxy == null)
          serviceProxy = new OrganizationServiceProxy(orgURI, null, credentials, DeviceCredentials);
        return serviceProxy;
      }
    }

    [NonSerialized]
    private SettingsManager settings;
    public SettingsManager Settings
    {
      get
      {
        if (settings == null)
          settings = new SettingsManager(Organization);

        return settings;
      }
    }

    public void ResetContext()
    {
      orgContext = null;
    }

    private OrganizationServiceContext orgContext;

    public OrganizationServiceContext OrgContext
    {
      get
      {
        if (orgContext == null)
        {
          try
          {
            orgContext = new OrganizationServiceContext(serviceProxy);
          }
          catch
          {
            serviceProxy = null;
            throw;
          }
        }
        return orgContext;
      }
    }

    public IQueryable<Entity> CreateQuery(string entityName)
    {
      ResetContext();
      return OrgContext.CreateQuery(entityName);
    }

    public void ApplyTable(DataTable table, string entityName)
    {
      ApplyTable(table, entityName, false);
    }

    public void ApplyTable(DataTable table, string entityName, bool applyNulls)
    {
      foreach (DataRow row in table.Rows)
      {
        UpdateRow(row, entityName, applyNulls);
      }
    }

    public void ApplyList(List<DynamicEntityProxy> list)
    {
      ApplyList(list, false);
    }

    public void ApplyList(List<DynamicEntityProxy> list, bool applyNulls)
    {
      foreach (DynamicEntityProxy proxy in list)
      {
        UpdateProxy(proxy);
      }
    }

    public object UpdateRow(DataRow row, string entityName)
    {
      return UpdateRow(row, entityName, false);
    }

    public object UpdateRow(DataRow row, string entityName, bool applyNulls)
    {
      DynamicEntityProxy proxy = row.ToProxy(entityName);
      return UpdateProxy(proxy);
    }

    public Guid? UpdateProxy(DynamicEntityProxy proxy)
    {
      return UpdateProxy(proxy, false);
    }

    public Guid? UpdateProxy(DynamicEntityProxy proxy, bool applyNulls)
    {
      Entity entity = proxy.ToEntity(this, applyNulls);
      try
      {
        if (proxy.Insert)
        {
          Guid? id = ServiceProxy.Create(entity);
          proxy.Id = id.Value;
          return id;
        }
        else if (proxy.Delete)
        {
          ServiceProxy.Delete(entity.LogicalName, entity.Id);
          return null;
        }
        else
        {
          ServiceProxy.Update(entity);
          return null;
        }
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    private Dictionary<string, EntityMetadata> metadataCache;

    public Dictionary<string, EntityMetadata> MetadataCache
    {
      get
      {
        if (metadataCache == null)
          metadataCache = new Dictionary<string, EntityMetadata>();
        return metadataCache;
      }
      set
      {
        metadataCache = value;
      }
    }

    internal void EnsureMetadataForEntity(string entityName)
    {
      if (!MetadataCache.ContainsKey(entityName))
      {
        RetrieveEntityRequest request = new RetrieveEntityRequest();
        request.EntityFilters = EntityFilters.Attributes;
        request.LogicalName = entityName;

        lock (MetadataCache)
        {
          try
          {
            if (!MetadataCache.ContainsKey(entityName))
              MetadataCache[entityName] = ((RetrieveEntityResponse)ServiceProxy.Execute(request)).EntityMetadata;
          }
          catch
          {
            serviceProxy = null;
            throw;
          }
        }
      }
    }

    public string GetIdPropertyName(string entityName)
    {
      EnsureMetadataForEntity(entityName);
      EntityMetadata entityMD = MetadataCache[entityName];
      return entityMD.PrimaryIdAttribute;
    }

    public List<string> GetRelevantProperties(string entityName, List<string> propertyList)
    {
      EnsureMetadataForEntity(entityName);
      EntityMetadata entityMD = MetadataCache[entityName];

      List<string> entityProperties = entityMD.Attributes.Select(x => x.LogicalName).ToList();
      propertyList = propertyList.Where(x => entityProperties.Contains(x)).ToList();

      return propertyList;
    }

    public List<AttributeMetadata> GetAttributesMetadata(string entityName)
    {
      EnsureMetadataForEntity(entityName);
      EntityMetadata entityMD = MetadataCache[entityName];

      List<AttributeMetadata> entityProperties = entityMD.Attributes.ToList();
      return entityProperties;
    }

    public void AssociateEntities(string parentEntityName, Guid parentID, string childEntityName, Guid childID, string relationName)
    {
      Dictionary<Guid, string> children = new Dictionary<Guid, string>();
      children[childID] = childEntityName;
      AssociateEntities(parentEntityName, parentID, relationName, children);
    }

    public void AssociateEntities(string parentEntityName, Guid parentID, string relationName, Dictionary<Guid, string> children)
    {
      EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
      foreach (KeyValuePair<Guid, string> child in children)
        relatedEntities.Add(new EntityReference(child.Value, child.Key));
      try
      {
        ServiceProxy.Associate(parentEntityName, parentID, new Relationship(relationName), relatedEntities);
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public void DisassociateEntities(string parentEntityName, Guid parentID, string childEntityName, Guid childID, string relationName)
    {
      DisassociateRequest dreq = new DisassociateRequest();
      dreq.Target = new EntityReference(parentEntityName, parentID);
      dreq.RelatedEntities = new EntityReferenceCollection();
      dreq.RelatedEntities.Add(new EntityReference(childEntityName, childID));
      dreq.Relationship = new Relationship(relationName);

      ServiceProxy.Execute(dreq);
    }


    public string GetAttributeDisplayLabel(string entityName, string attributeName)
    {
      if (string.IsNullOrEmpty(attributeName))
        return attributeName;


      EnsureMetadataForEntity(entityName);
      attributeName = attributeName.ToLower();

      AttributeMetadata attribute = metadataCache[entityName].Attributes.Where(x => x.LogicalName == attributeName).FirstOrDefault();
      if (attribute != null)
      {
        if (attribute.DisplayName.UserLocalizedLabel != null)
          return attribute.DisplayName.UserLocalizedLabel.Label;
      }

      return attributeName;
    }

    public bool IsMoneyAttribute(string entityName, string attributeName)
    {
      EnsureMetadataForEntity(entityName);
      attributeName = attributeName.ToLower();

      AttributeMetadata attribute = metadataCache[entityName].Attributes.Where(x => x.LogicalName == attributeName).FirstOrDefault();
      if ((attribute != null) && (attribute.AttributeType.HasValue))
      {
        return attribute.AttributeType.Value == AttributeTypeCode.Money;
      }

      return false;
    }


    public Dictionary<string, string> GetPickListOptions(string entityName, string attributeName)
    {
      EnsureMetadataForEntity(entityName);
      attributeName = attributeName.ToLower();
      AttributeMetadata attribute = metadataCache[entityName].Attributes.Where(x => x.LogicalName == attributeName).FirstOrDefault();


      if (attribute != null)
      {
        OptionMetadataCollection options = null;
        Dictionary<string, string> pickListOptions = new Dictionary<string, string>();

        if (attribute is EnumAttributeMetadata)
        {
          pickListOptions[""] = "";
          EnumAttributeMetadata enumAttribute = (EnumAttributeMetadata)attribute;
          options = enumAttribute.OptionSet.Options;

        }
        else if (attribute is BooleanAttributeMetadata)
        {
          BooleanAttributeMetadata boolAttribute = (BooleanAttributeMetadata)attribute;
          options = new OptionMetadataCollection();
          options.Add(boolAttribute.OptionSet.FalseOption);
          options.Add(boolAttribute.OptionSet.TrueOption);
        }

        if (options != null)
        {
          foreach (OptionMetadata item in options)
          {
            pickListOptions[item.Label.UserLocalizedLabel.Label] = Convert.ToString(item.Value.Value);
          }
          return pickListOptions;
        }
      }

      return null;
    }

    public DataTable CreateEntityTable(string entityName, string[] columnset)
    {
      entityName = entityName.ToLower();
      EnsureMetadataForEntity(entityName);
      DataTable table = new DataTable(entityName);
      Dictionary<string, AttributeMetadata> attributes = MetadataCache[entityName].Attributes.ToDictionary(x => x.LogicalName);
      foreach (string item in columnset)
      {
        AttributeMetadata atm = attributes[item];
        if (atm.AttributeType.HasValue)
        {
          Type columnType = null;
          switch (atm.AttributeType.Value)
          {
            case AttributeTypeCode.BigInt:
              columnType = typeof(long);
              break;
            case AttributeTypeCode.Boolean:
              columnType = typeof(bool);
              break;
            case AttributeTypeCode.Lookup:
            case AttributeTypeCode.Owner:
            case AttributeTypeCode.Uniqueidentifier:
            case AttributeTypeCode.Customer:
              columnType = typeof(Guid);
              break;
            case AttributeTypeCode.DateTime:
              columnType = typeof(DateTime);
              break;

            case AttributeTypeCode.Money:
            case AttributeTypeCode.Decimal:
              columnType = typeof(decimal);
              break;
            case AttributeTypeCode.Double:
              columnType = typeof(double);
              break;
            case AttributeTypeCode.String:
            case AttributeTypeCode.EntityName:
            case AttributeTypeCode.Memo:
              columnType = typeof(string);
              break;
            case AttributeTypeCode.Picklist:
            case AttributeTypeCode.State:
            case AttributeTypeCode.Status:
            case AttributeTypeCode.Integer:
              columnType = typeof(int);
              break;
          }
          table.Columns.Add(item, columnType);
        }
      }
      return table;
    }


    /// <summary>
    /// Executa uma consulta QBE (Query By Example) no serviço a partir de um proxy e de uma lista de condições passados como parâmetro.
    /// </summary>
    /// <param name="proxy">Um proxy para a entidade na qual será feita a consulta, 
    /// preenchido com os valores que servirão de parâmetro na consulta    /// 
    /// </param>
    /// <param name="conditions">
    /// Lista de condções no seguinte formato:
    ///   "nomeCampo1 & nomeCampo2 & nomeCampo3 ... & nomeCampoN".
    /// 
    /// Cada item da lista deve conter uma combinação de campos presente no proxy, separados pelo operador lógico &
    /// 
    /// Os itens da lista devem ser criados e adicionados por ordem de importância, sendo adicionando as combinações 
    /// consideradas mais importantes/determinantes antes das consideradas secundárias/menos determinantes
    /// 
    /// </param>
    /// <returns></returns>
    public DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions, bool activeRecordsOnly)
    {
      return ExecuteQBE(proxy, conditions, activeRecordsOnly, null);
    }

    public DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions, bool activeRecordsOnly, FilterExpression preFilter)
    {
      try
      {
        DataTable table = CrmQbe.ExecuteQBE(proxy, conditions, this, activeRecordsOnly, preFilter);

        if (table != null)
          GetTableDisplayNames(proxy, table);

        return table;
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    private void GetTableDisplayNames(DynamicEntityProxy proxy, DataTable table)
    {
      foreach (DataColumn column in table.Columns)
      {
        column.Caption = GetAttributeDisplayLabel(proxy.EntityName, column.ColumnName);
      }

    }

    public DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions, List<int> ranking, bool activeRecordsOnly)
    {
      try
      {
        DataTable table = CrmQbe.ExecuteQBE(proxy, conditions, ranking, this, activeRecordsOnly);
        GetTableDisplayNames(proxy, table);
        return table;
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public DataTable ExecuteQBE(DynamicEntityProxy proxy, Dictionary<string, int> ranking, Dictionary<string, int> approxRanking, bool activeRecordsOnly)
    {
      try
      {
        DataTable table = CrmQbe.ExecuteQBE(proxy, ranking, approxRanking, this, activeRecordsOnly);
        GetTableDisplayNames(proxy, table);
        return table;
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions, Dictionary<string, int> ranking,
      Dictionary<string, int> approxRanking, bool activeRecordsOnly)
    {
      try
      {
        DataTable table = CrmQbe.ExecuteQBE(proxy, conditions, ranking, approxRanking, this, activeRecordsOnly);
        GetTableDisplayNames(proxy, table);
        return table;
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public Guid? GetIdFromProxy(DynamicEntityProxy proxy)
    {
      if ((proxy.Id != null) && (proxy.Id.HasValue))
        return proxy.Id;
      else
      {
        string idName = GetIdPropertyName(proxy.EntityName);
        Guid? id = null;

        if (proxy[idName] is string)
        {
          string strId = Convert.ToString(proxy[idName]);
          if (strId.Contains('|'))
            strId = strId.Substring(strId.IndexOf('|') + 1);

          id = new Guid(strId);
        }
        else
        {
          id = (Guid?)proxy[idName];
        }

        return id;
      }
    }

    public void SetState(DynamicEntityProxy proxy)
    {
      SetStateRequest request = new SetStateRequest();
      Guid? id = GetIdFromProxy(proxy);

      request.EntityMoniker = new EntityReference(proxy.EntityName.ToLower(), id.Value);

      if (proxy["statecode"] != null)
      {
        request.State = new OptionSetValue(Convert.ToInt32(proxy["statecode"]));
      }

      if (proxy["statuscode"] != null)
      {
        request.Status = new OptionSetValue(Convert.ToInt32(proxy["statuscode"]));
      }
      try
      {
        ServiceProxy.Execute(request);
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public void LoseOpportunity(Guid opportunityId, int statuscode, string subject)
    {
      LoseOpportunityRequest request = new LoseOpportunityRequest();
      request.OpportunityClose = new Entity("opportunityclose");
      request.OpportunityClose["subject"] = subject;
      request.OpportunityClose["opportunityid"] = new EntityReference("opportunity", opportunityId);
      request.Status = new OptionSetValue(statuscode);

      try
      {
        ServiceProxy.Execute(request);
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public DynamicEntityProxy Retrieve(string entityName, Guid id, params string[] columnNames)
    {
      ColumnSet columnSet = new ColumnSet(columnNames);
      try
      {
        Entity entity = ServiceProxy.Retrieve(entityName, id, columnSet);
        return entity.ToProxy();
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public List<DynamicEntityProxy> RetrieveMultiple(string entityName, Dictionary<string, object> conditions, params string[] columns)
    {
      FilterExpression criteria = new FilterExpression();
      foreach (KeyValuePair<string, object> item in conditions)
      {
        criteria.AddCondition(item.Key, ConditionOperator.Equal, item.Value);
      }

      return RetrieveMultiple(entityName, criteria, columns);
    }


    public List<DynamicEntityProxy> RetrieveMultiple(string entityName, FilterExpression criteria, params string[] columnNames)
    {
      QueryExpression query = new QueryExpression(entityName);
      ColumnSet columnSet = new ColumnSet(columnNames);
      query.ColumnSet = columnSet;
      query.NoLock = true;
      query.PageInfo.PageNumber = 1;
      query.PageInfo.ReturnTotalRecordCount = true;
      query.PageInfo.Count = 5000;


      if (criteria.Conditions.Count > 0)
        query.Criteria = criteria;

      try
      {
        List<DynamicEntityProxy> lst = new List<DynamicEntityProxy>();
        string pagingCookie = "";
        while (true)
        {
          EntityCollection entities = ServiceProxy.RetrieveMultiple(query);
          pagingCookie = entities.PagingCookie;

          if (entities != null)
          {
            if (entities.Entities.Count != 0)
              lst.AddRange(entities.Entities.Select(x => x.ToProxy()).ToList());

            if (entities.MoreRecords)
            {
              query.PageInfo.PageNumber++;
              query.PageInfo.PagingCookie = pagingCookie;
            }
            else
              break;
          }
          else
            break;
        }

        return lst;
      }
      catch
      {
        serviceProxy = null;
        throw;
      }
    }

    public void Dispose()
    {
      if (serviceProxy != null)
      {
        serviceProxy.Dispose();
      }
    }

    public DataTable CreateEntityTable(string entityName, IEnumerable<string> columns, List<DynamicEntityProxy> list)
    {
      DataTable table = CreateEntityTable(entityName, columns.ToArray());

      table.BeginLoadData();
      foreach (DynamicEntityProxy proxyItem in list)
      {
        DataRow row = proxyItem.ToDataRow(table);
        table.LoadDataRow(row.ItemArray, true);
      }
      table.EndLoadData();
      return table;
    }
  }
}
