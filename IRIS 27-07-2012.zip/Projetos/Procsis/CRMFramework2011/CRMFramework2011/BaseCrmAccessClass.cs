﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRMFramework;
using Microsoft.Xrm.Sdk;

namespace CRMFramework2011
{
  public abstract class BaseCrmAccessClass
  {
    protected IPluginExecutionContext context;


    protected string organization;
    protected virtual string Organization
    {
      get
      {
        return context.OrganizationName.Trim();
      }
    }

    private ServiceManager service;
    protected ServiceManager Service
    {
      get
      {
        if (service == null)
          service = new ServiceManager(Organization);
        return service;
      }
    }

    private DBManager db;
    protected virtual DBManager DB
    {
      get
      {
        if (db == null)
          db = new DBManager(Organization);
        return db;
      }
    }

  }
}
