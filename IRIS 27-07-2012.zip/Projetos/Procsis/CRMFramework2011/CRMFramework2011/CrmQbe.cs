﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;


namespace CRMFramework2011
{
  internal static class CrmQbe
  {
    /// <summary>
    /// Executa uma consulta QBE (Query By Example) no serviço a partir de um proxy e de uma lista de condições passados como parâmetro.
    /// </summary>
    /// <param name="proxy">Um proxy para a entidade na qual será feita a consulta, 
    /// preenchido com os valores que servirão de parâmetro na consulta    /// 
    /// </param>
    /// <param name="conditions">
    /// Lista de condções no seguinte formato:
    ///   "nomeCampo1 & nomeCampo2 & nomeCampo3 ... & nomeCampoN".
    /// 
    /// Cada item da lista deve conter uma combinação de campos presente no proxy, separados pelo operador lógico &
    /// 
    /// Os itens da lista devem ser criados e adicionados por ordem de importância, sendo adicionando as combinações 
    /// consideradas mais importantes/determinantes antes das consideradas secundárias/menos determinantes
    /// 
    /// </param>
    /// <returns></returns>
    internal static DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions, ServiceManager service, bool activeRecordsOnly)
    {
      return ExecuteQBE(proxy, conditions, service, activeRecordsOnly, null);
    }

    internal static DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions, ServiceManager service,
      bool activeRecordsOnly, FilterExpression preFilter)
    {
      QueryExpression query = new QueryExpression(proxy.EntityName);

      List<string> columns = proxy.Properties.Select(x => x.Key).ToList();
      string idProperty = service.GetIdPropertyName(proxy.EntityName);
      if (!columns.Contains(idProperty))
        columns.Add(idProperty);

      query.ColumnSet = new ColumnSet(columns.ToArray());

      if (proxy.Properties.ContainsKey(idProperty))
        proxy.Properties.Remove(idProperty);

      FilterExpression filter = new FilterExpression(LogicalOperator.Or);

      for (int i = 0; i < conditions.Count; i++)
      {
        FilterExpression conditionFilter = GetConditionFilter(proxy, conditions[i]);
        if (conditionFilter != null)
          filter.AddFilter(conditionFilter);
      }

      if (preFilter != null)
      {
        FilterExpression activeFilter = new FilterExpression(LogicalOperator.And);
        activeFilter.AddFilter(filter);
        activeFilter.AddFilter(preFilter);
        filter = activeFilter;
      }

      if (filter.Filters.Count == 0)
      {
        return null;
      }
      else
      {
        if (activeRecordsOnly)
        {
          FilterExpression activeFilter = new FilterExpression(LogicalOperator.And);
          activeFilter.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
          activeFilter.AddFilter(filter);
          query.Criteria = activeFilter;
        }
        else
        {
          query.Criteria = filter;
        }

        List<DynamicEntityProxy> qbeResult = service.ServiceProxy.RetrieveMultiple(query).Entities.Select(x => new DynamicEntityProxy(x)).ToList();

        string tableEntityName = proxy.EntityName;

        return service.CreateEntityTable(tableEntityName,columns, qbeResult);
      }
    }



    internal static DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions, List<int> ranking, ServiceManager service, bool activeRecordsOnly)
    {
      DataTable table = ExecuteQBE(proxy, conditions, service, activeRecordsOnly);
      table.Columns.Add("Ranking");

      table.Rows.Cast<DataRow>().ToList().ForEach(x => TestDataRowForCriteria(proxy, x, conditions, ranking));

      return table;
    }

    internal static DataTable ExecuteQBE(DynamicEntityProxy proxy, Dictionary<string, int> ranking,
      Dictionary<string, int> approxRanking, ServiceManager service, bool activeRecordsOnly)
    {
      string condition = "";
      foreach (KeyValuePair<string, int> item in ranking)
      {
        condition += item.Key + "&";
      }
      condition = condition.TrimEnd('&');
      List<string> conditions = new List<string>();
      conditions.Add(condition);

      return ExecuteQBE(proxy, conditions, ranking, approxRanking, service, activeRecordsOnly);
    }

    internal static DataTable ExecuteQBE(DynamicEntityProxy proxy, List<string> conditions,
      Dictionary<string, int> ranking, Dictionary<string, int> approxRanking, ServiceManager service, bool activeRecordsOnly)
    {
      DataTable table = ExecuteQBE(proxy, conditions, service, activeRecordsOnly);
      table.Columns.Add("Ranking", typeof(int));

      table.Rows.Cast<DataRow>().ToList().ForEach(x => TestDataRowForCriteria(proxy, x, ranking, approxRanking));

      return table;
    }

    private static void TestDataRowForCriteria(DynamicEntityProxy proxy, DataRow row,
      Dictionary<string, int> ranking, Dictionary<string, int> approxRanking)
    {
      int score = 0;

      foreach (KeyValuePair<string, int> item in ranking)
      {
        string attributeName = item.Key;
        if (proxy.Properties.ContainsKey(attributeName) && row.Table.Columns.Contains(attributeName)
          && (!Convert.IsDBNull(row[attributeName])) && (proxy[attributeName] != null))
        {
          string proxyValue = Convert.ToString(proxy[attributeName]).ToLower().TrimEnd('%');
          string rowValue = Convert.ToString(row[attributeName]).ToLower();

          if (proxyValue == rowValue)
            score += ranking[attributeName];
          else if (rowValue.StartsWith(proxyValue))
            score += approxRanking[attributeName];
        }
      }

      row["Ranking"] = score;
    }

    private static void TestDataRowForCriteria(DynamicEntityProxy proxy, DataRow row,
      List<string> conditions, List<int> ranking)
    {
      row["Ranking"] = 0;

      for (int j = 0; j < conditions.Count; j++)
      {
        List<string> conditionMembers = conditions[j].Split('&').Select(x => x.Trim().ToLower()).ToList();
        bool criteriaMet = true;

        for (int i = 0; i < conditionMembers.Count; i++)
        {
          string prop = conditionMembers[i];
          if ((proxy.Properties.ContainsKey(prop)) && (!Convert.IsDBNull(row[prop])) && (row[prop] != null))
          {
            if (proxy[prop] is string)
              criteriaMet &= Convert.ToString(row[prop]).StartsWith(Convert.ToString(proxy[prop]).TrimEnd('%'));
            else
              criteriaMet &= Convert.ToString(row[prop]).Equals(Convert.ToString(proxy[prop]), StringComparison.InvariantCultureIgnoreCase);
          }
          else
          {
            criteriaMet = false;
            break;
          }
        }

        if (criteriaMet)
        {
          row["Ranking"] = ranking[j];
          break;
        }
      }

    }

    private static FilterExpression GetConditionFilter(DynamicEntityProxy proxy, string condition)
    {
      FilterExpression filter = new FilterExpression(LogicalOperator.And);
      List<string> conditionMembers = condition.Split('&').Select(x => x.Trim().ToLower()).ToList();
      for (int i = 0; i < conditionMembers.Count; i++)
      {
        string propertyName = conditionMembers[i];
        if ((proxy[propertyName] != null) && (!String.IsNullOrEmpty(Convert.ToString(proxy[propertyName])))
          && (proxy.Properties.ContainsKey(propertyName)))
        {
          string value = Convert.ToString(proxy[propertyName]);
          if (value.Contains('%'))
            filter.AddCondition(propertyName, ConditionOperator.Like, value);
          else
            filter.AddCondition(propertyName, ConditionOperator.Equal, proxy[propertyName]);
        }
      }

      if (filter.Conditions.Count > 0)
        return filter;
      else
        return null;
    }

  }
}
