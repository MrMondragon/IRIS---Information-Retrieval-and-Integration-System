﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using System.Net;
using CRMFramework;
using System.ServiceModel.Description;

namespace CRMFramework2011
{
  public class SettingsManager : BaseSettingsManager
  {
    public SettingsManager(string organization)
      : base(organization)
    {
    }

    public string ServiceAddress
    {
      get
      {
        if (!UseHttps)
          return string.Format(@"http://{0}/{1}/XRMServices/2011/Organization.svc", CrmServer, organization);
        else
          return string.Format(@"https://{0}/{1}/XRMServices/2011/Organization.svc", CrmServer, organization);
      }
    }


    protected virtual ClientCredentials GetDeviceCredentials()
    {
      return Microsoft.Crm.Services.Utility.DeviceIdManager.LoadOrRegisterDevice();
    }
  }
}
