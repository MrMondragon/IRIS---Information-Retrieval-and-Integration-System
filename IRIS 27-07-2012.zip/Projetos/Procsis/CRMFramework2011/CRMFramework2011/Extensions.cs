﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.Xrm.Sdk;

namespace CRMFramework2011
{
  public static class Extensions
  {
    public static List<DynamicEntityProxy> ToProxyList(this DataTable table, string entityName)
    {
      return table.Rows.Cast<DataRow>().Select(x => new DynamicEntityProxy(entityName, x)).ToList();
    }

    public static List<DynamicEntityProxy> ToProxyList(this DataTable table, string entityName, DataViewRowState rowState)
    {
      return table.Select("", "", rowState).Select(x => new DynamicEntityProxy(entityName, x)).ToList();
    }

    public static DynamicEntityProxy ToProxy(this DataRow row, string entityName)
    {
      return new DynamicEntityProxy(entityName, row);
    }

    public static void Merge(this DataTable table, DataTable mergingTable, string idFieldName)
    {
      List<Guid> sourceIds = table.Rows.Cast<DataRow>().Select(x => (Guid)x[idFieldName]).ToList();

      for (int i = 0; i < mergingTable.Rows.Count; i++)
      {
        Guid id = (Guid)mergingTable.Rows[i][idFieldName];
        if (!sourceIds.Contains(id))
          table.LoadDataRow(mergingTable.Rows[i].ItemArray, true);
      }
    }

    public static DynamicEntityProxy ToProxy(this Entity entity)
    {
      return new DynamicEntityProxy(entity);
    }

  }

}
