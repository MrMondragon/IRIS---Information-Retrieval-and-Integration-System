﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;

namespace CRMFramework2011
{
  [Serializable]
  public class DynamicEntityProxy
  {

    public DynamicEntityProxy(string entityName)
    {
      this.entityName = entityName;
      properties = new Dictionary<string, object>();
      lookupTypes = new Dictionary<string, string>();
    }

    public DynamicEntityProxy(string entityName, DataRow row)
      : this(entityName)
    {
      foreach (DataColumn column in row.Table.Columns)
      {
        this[column.ColumnName] = row[column.ColumnName];
      }

      insert = row.RowState == DataRowState.Added;
      delete = row.RowState == DataRowState.Deleted;
    }

    public DynamicEntityProxy(Entity entity)
      : this(entity.LogicalName)
    {
      this.id = entity.Id;

      foreach (KeyValuePair<string, object> prop in entity.Attributes)
      {
        if (prop.Value is Money)
          this[prop.Key] = ((Money)prop.Value).Value;
        else if (prop.Value is OptionSetValue)
          this[prop.Key] = ((OptionSetValue)prop.Value).Value;
        else if (prop.Value is EntityReference)
        {
          this[prop.Key] = ((EntityReference)prop.Value).Id;
          lookupTypes[prop.Key] = ((EntityReference)prop.Value).LogicalName;
        }
        else
          this[prop.Key] = prop.Value;
      }
    }


    private bool insert;

    public bool Insert
    {
      get { return insert; }
      set { insert = value; }
    }

    private bool delete;

    public bool Delete
    {
      get { return delete; }
      set { delete = value; }
    }

    private Guid? id;

    public Guid? Id
    {
      get { return id; }
      set { id = value; }
    }

    private Dictionary<string, string> lookupTypes;

    public Dictionary<string, string> LookupTypes
    {
      get { return lookupTypes; }
    }


    private Dictionary<string, object> properties;

    public Dictionary<string, object> Properties
    {
      get { return properties; }
    }

    private string entityName;

    public string EntityName
    {
      get
      {
        return entityName.ToLower();
      }
    }

    public object this[string propertyName]
    {
      get
      {
        if (properties.ContainsKey(propertyName.ToLower()))
          return properties[propertyName.ToLower()];
        else
          return null;
      }
      set
      {
        properties[propertyName.ToLower()] = value;
      }
    }

    /// <summary>
    /// Converte o proxy para um registro da tabela passada como parÃ¢metro
    /// </summary>
    /// <param name="proxy"></param>
    /// <param name="table"></param>
    /// <returns></returns>
    public DataRow ToDataRow(DataTable table)
    {
      DataRow row = table.NewRow();
      foreach (DataColumn column in table.Columns)
      {
        if (this[column.ColumnName] == null)
          row[column.ColumnName] = DBNull.Value;
        else
          row[column] = this[column.ColumnName];
      }
      return row;
    }

    public Entity ToEntity(ServiceManager service, bool applyNulls)
    {

      Entity entity = new Entity(EntityName);
      service.EnsureMetadataForEntity(EntityName);

      Guid? proxyId = null;

      if (!Insert)
        proxyId = service.GetIdFromProxy(this);

      Dictionary<string, AttributeMetadata> attributes = service.MetadataCache[EntityName].Attributes.ToDictionary(x => x.LogicalName);

      if ((!Insert) && (proxyId.HasValue))
      {
        this[service.GetIdPropertyName(EntityName)] = proxyId.Value;
        entity.Id = proxyId.Value;
      }

      foreach (KeyValuePair<string, object> prop in Properties)
      {
        if (HasValue(prop.Key) || applyNulls)
        {
          string propName = prop.Key.ToLower();
          try
          {

            if (attributes.ContainsKey(propName))
            {
              AttributeMetadata metadata = attributes[propName];
              AttributeTypeCode atc = metadata.AttributeType.Value;

              if (applyNulls && ((this[propName] == null) ||
                    (String.IsNullOrEmpty(Convert.ToString(this[propName])))))
                entity[propName] = null;
              else
              {

                switch (atc)
                {
                  case AttributeTypeCode.BigInt:
                    entity[propName] = Convert.ToInt64(this[propName]);
                    break;
                  case AttributeTypeCode.Boolean:
                    {
                      if ((this[propName] is string) || (this[propName] is int))
                      {
                        BooleanAttributeMetadata boolAttribute = attributes[propName] as BooleanAttributeMetadata;
                        entity[propName] = (Convert.ToInt32(this[propName]) == boolAttribute.OptionSet.TrueOption.Value.Value);
                        break;
                      }
                      else
                      {
                        entity[propName] = this[propName];
                        break;
                      }
                    }
                  case AttributeTypeCode.DateTime:
                    entity[propName] = Convert.ToDateTime(this[propName]);
                    break;
                  case AttributeTypeCode.Decimal:
                    entity[propName] = Convert.ToDecimal(this[propName]);
                    break;
                  case AttributeTypeCode.Double:
                    entity[propName] = Convert.ToDouble(this[propName]);
                    break;
                  case AttributeTypeCode.Integer:
                    entity[propName] = Convert.ToInt32(this[propName]);
                    break;
                  case AttributeTypeCode.Uniqueidentifier:
                    entity[propName] = new Guid(Convert.ToString(this[propName]));
                    break;
                  case AttributeTypeCode.Memo:
                  case AttributeTypeCode.String:
                    entity[propName] = Convert.ToString(this[propName]);
                    break;
                  case AttributeTypeCode.Customer:
                  case AttributeTypeCode.Lookup:
                  case AttributeTypeCode.Owner:
                    {
                      Guid value;
                      LookupAttributeMetadata lkpAttribute = (LookupAttributeMetadata)metadata;
                      EntityReference reference;
                      string targetEntity = "";
                      if (this[propName] is Guid)
                        value = (Guid)this[propName];
                      else
                      {
                        string valueStr = Convert.ToString(this[propName]);
                        if (valueStr.Contains('|'))
                        {
                          string[] parts = valueStr.Split('|');
                          value = new Guid(parts[1]);
                          targetEntity = parts[0];
                        }
                        else
                          value = new Guid(valueStr);
                      }

                      if (string.IsNullOrEmpty(targetEntity))
                      {
                        if (this.LookupTypes.ContainsKey(propName))
                          targetEntity = this.LookupTypes[propName];
                        else
                          targetEntity = lkpAttribute.Targets[0];
                      }

                      reference = new EntityReference(targetEntity, value);

                      entity[propName] = reference;
                    }
                    break;
                  case AttributeTypeCode.Money:
                    entity[propName] = new Money(Convert.ToDecimal(this[propName]));
                    break;
                  case AttributeTypeCode.Picklist:
                  case AttributeTypeCode.State:
                  case AttributeTypeCode.Status:
                    {
                      OptionSetValue value;
                      if (this[propName] == null)
                        value = new OptionSetValue(-1);
                      else
                        value = new OptionSetValue(Convert.ToInt32(this[propName]));

                      entity[propName] = value;
                    }
                    break;
                }
              }
            }
          }
          catch (Exception e)
          {
            throw new Exception(String.Format("Falha na atribuição do campo {0}. Mensagem original: {1}", propName, e.Message));
          }
        }
      }
      return entity;

    }

    public bool HasValue(string propertyName)
    {
      propertyName = propertyName.ToLower();


      return (!Convert.IsDBNull(this[propertyName])) && (this[propertyName] != null) && (Convert.ToString(this[propertyName]) != "");
    }

  }
}