﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using CRMFramework2011;
using Microsoft.Xrm.Sdk.Query;
using CRMFramework;

namespace CRMFramework2011
{
  public abstract class BaseCrmPlugin : BaseCrmAccessClass, IPlugin
  {
    public void Execute(IServiceProvider serviceProvider)
    {
      // Obtain the execution context from the service provider.
      context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

      // The InputParameters collection contains all the data passed in the message request.
      if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
      {
        // Obtain the target entity from the input parmameters.
        entity = (Entity)context.InputParameters["Target"];
      }

      if (context.Depth > MaxDepht)
      {
        return;
      }


      doExecute();

    }

    protected abstract void doExecute();
    protected Entity entity;

    protected virtual int MaxDepht
    {
      get
      {
        return 1;
      }
    }

    

  }
}
