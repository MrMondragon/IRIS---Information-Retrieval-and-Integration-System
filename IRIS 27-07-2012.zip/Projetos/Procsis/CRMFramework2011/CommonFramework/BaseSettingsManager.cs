﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using System.Net;

namespace CRMFramework
{
  public class BaseSettingsManager
  {
    public BaseSettingsManager(string organization)
    {
      this.organization = organization;
    }

    protected string organization;

    protected string RegistryPath
    {
      get
      {
        string path = Registry.LocalMachine + "\\Software\\Procsis\\" + organization;
        return path;
      }
    }

    protected string RegistryPath32
    {
      get
      {
        string path = Registry.LocalMachine + "\\Software\\Wow6432Node\\Procsis\\" + organization;
        return path;
      }
    }


    protected string CustomSettingsPath
    {
      get
      {
        string path = Registry.LocalMachine + "\\SOFTWARE\\Procsis\\" + organization + "\\CustomSettings";
        return path;
      }
    }

    protected string CustomSettingsPath32
    {
      get
      {
        string path = Registry.LocalMachine + "\\SOFTWARE\\Wow6432Node\\Procsis\\" + organization + "\\CustomSettings";
        return path;
      }
    }

    protected Dictionary<string, string> customSettings;
    public Dictionary<string, string> CustomSettings
    {
      get
      {
        if (customSettings == null)
        {
          customSettings = new Dictionary<string, string>();

          RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Procsis\\" + organization + "\\CustomSettings");
          if (key != null)
          {

            string[] valueNames = key.GetValueNames();
            foreach (string valueName in valueNames)
            {
              string value = Convert.ToString(key.GetValue(valueName));
              customSettings[valueName] = Cryptography.Decrypt(value, "\\Software\\Procsis" + organization);
            }
          }
        }
        return customSettings;
      }
      set
      {
        customSettings = value;
        SaveSettings();
      }
    }

    public void SaveSettings()
    {
      foreach (KeyValuePair<string, string> item in CustomSettings)
      {
        Registry.SetValue(CustomSettingsPath, item.Key, Cryptography.Encrypt(item.Value, "\\Software\\Procsis" + organization));
        Registry.SetValue(CustomSettingsPath32, item.Key, Cryptography.Encrypt(item.Value, "\\Software\\Procsis" + organization));
      }
    }

    public void DeleteCustomSetting(string valueName)
    {
      RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Procsis\\" + organization + "\\CustomSettings", true);
      if (key != null)
        key.DeleteValue(valueName);
      customSettings = null;
    }

    public string ServicePassword
    {
      get
      {
        string pwd = Convert.ToString(Registry.GetValue(RegistryPath, "SvcPd", ""));
        if (!string.IsNullOrEmpty(pwd))
          pwd = Cryptography.Decrypt(pwd, "\\Software\\Procsis" + organization);
        return pwd;
      }
      set
      {
        Registry.SetValue(RegistryPath, "SvcPd", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
        Registry.SetValue(RegistryPath32, "SvcPd", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
      }
    }

    public string ServiceUser
    {
      get
      {
        string cs = Convert.ToString(Registry.GetValue(RegistryPath, "Usr", ""));
        if (!string.IsNullOrEmpty(cs))
          cs = Cryptography.Decrypt(cs, "\\Software\\Procsis" + organization);
        return cs;
      }
      set
      {
        Registry.SetValue(RegistryPath, "Usr", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
        Registry.SetValue(RegistryPath32, "Usr", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
      }
    }

    public string Domain
    {
      get
      {
        return Convert.ToString(Registry.GetValue(RegistryPath, "Domain", ""));
      }
      set
      {
        Registry.SetValue(RegistryPath, "Domain", value);
        Registry.SetValue(RegistryPath32, "Domain", value);
      }
    }

    public string CrmServer
    {
      get
      {
        return Convert.ToString(Registry.GetValue(RegistryPath, "CrmServer", ""));
      }
      set
      {
        Registry.SetValue(RegistryPath, "CrmServer", value);
        Registry.SetValue(RegistryPath32, "CrmServer", value);
      }
    }

    public Boolean UseDefaultUser
    {
      get
      {
        return Convert.ToBoolean(Registry.GetValue(RegistryPath, "DefaultUser", false));
      }
      set
      {
        Registry.SetValue(RegistryPath, "DefaultUser", value);
        Registry.SetValue(RegistryPath32, "DefaultUser", value);
      }
    }


    public Boolean UseHttps
    {
      get
      {
        return Convert.ToBoolean(Registry.GetValue(RegistryPath, "UseHttps", false));
      }
      set
      {
        Registry.SetValue(RegistryPath, "UseHttps", value);
        Registry.SetValue(RegistryPath32, "UseHttps", value);
      }
    }



    public String DbServer
    {
      get
      {
        return Convert.ToString(Registry.GetValue(RegistryPath, "DbServer", ""));
      }
      set
      {
        Registry.SetValue(RegistryPath, "DbServer", value);
        Registry.SetValue(RegistryPath32, "DbServer", value);
      }
    }

    public Boolean IntegratedSecurity
    {
      get
      {
        return Convert.ToBoolean(Registry.GetValue(RegistryPath, "IntegratedSecurity", false));
      }
      set
      {
        Registry.SetValue(RegistryPath, "IntegratedSecurity", value);
        Registry.SetValue(RegistryPath32, "IntegratedSecurity", value);
      }
    }

    public string DbUser
    {
      get
      {
        string cs = Convert.ToString(Registry.GetValue(RegistryPath, "DbUser", ""));
        if (!string.IsNullOrEmpty(cs))
          cs = Cryptography.Decrypt(cs, "\\Software\\Procsis" + organization);
        return cs;
      }
      set
      {
        Registry.SetValue(RegistryPath, "DbUser", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
        Registry.SetValue(RegistryPath32, "DbUser", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
      }
    }

    public string InitialCatalog
    {

      get
      {
        string cs = Convert.ToString(Registry.GetValue(RegistryPath, "InitialCatalog", ""));
        if (!string.IsNullOrEmpty(cs))
          cs = Cryptography.Decrypt(cs, "\\Software\\Procsis" + organization);
        else
          cs = organization + "_mscrm";
        return cs;
      }
      set
      {
        Registry.SetValue(RegistryPath, "InitialCatalog", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
        Registry.SetValue(RegistryPath32, "InitialCatalog", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
      }
    }

    public string DbPwd
    {
      get
      {
        string cs = Convert.ToString(Registry.GetValue(RegistryPath, "DbPd", ""));
        if (!string.IsNullOrEmpty(cs))
          cs = Cryptography.Decrypt(cs, "\\Software\\Procsis" + organization);
        return cs;
      }
      set
      {
        Registry.SetValue(RegistryPath, "DbPd", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
        Registry.SetValue(RegistryPath32, "DbPd", Cryptography.Encrypt(value, "\\Software\\Procsis" + organization));
      }
    }

    public string CRMConnectionString
    {
      get
      {
        if (IntegratedSecurity)
        {
          return string.Format(@"Data Source={0};Initial Catalog={1};Integrated Security=True", DbServer, InitialCatalog);
        }
        else
        {
          return string.Format(@"Data Source={0};Initial Catalog={1};User ID={2};Password={3}", DbServer, InitialCatalog, DbUser, DbPwd);
        }
      }
    }

    public NetworkCredential Credentials
    {
      get
      {
        if (UseDefaultUser)
          return null;
        else
        {
          NetworkCredential credential = new NetworkCredential(ServiceUser, ServicePassword, Domain);
          return credential;
        }
      }
    }
  }
}
