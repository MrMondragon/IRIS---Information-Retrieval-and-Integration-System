﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace CRMFramework
{
  public class DBManager
  {
    public DBManager(string organization)
    {
      settings = new BaseSettingsManager(organization);
      connectionString = settings.CRMConnectionString;
    }

    public DBManager(string organization, string customSettingsKey)
    {
      settings = new BaseSettingsManager(organization);
      connectionString = settings.CustomSettings[customSettingsKey];
    }

    private string connectionString;

    private SqlConnection GetConnection()
    {
      SqlConnection connection = new SqlConnection(connectionString);
      connection.Open();
      return connection;
    }

    private BaseSettingsManager settings;

    public Object ExecuteScalar(string commandText)
    {
      using (SqlConnection connection = GetConnection())
      {
        SqlCommand cmd = connection.CreateCommand();
        cmd.CommandText = commandText;
        return cmd.ExecuteScalar();
      }
    }

    public int ExecuteNonQuery(string commandText)
    {
      using (SqlConnection connection = GetConnection())
      {
        SqlCommand cmd = connection.CreateCommand();
        cmd.CommandText = commandText;
        return cmd.ExecuteNonQuery();
      }

    }

    public DataTable ExecuteCommand(string commandText, params object[] parameters)
    {
      return ExecuteCommand(string.Format(commandText, parameters));
    }

    public DataTable ExecuteCommand(string commandText)
    {
      using (SqlConnection connection = GetConnection())
      {
        SqlCommand cmd = connection.CreateCommand();
        cmd.CommandTimeout = 12000;
        cmd.CommandText = commandText;
        return ExecuteCommand(cmd);
      }
    }

    private DataTable ExecuteCommand(SqlCommand cmd)
    {
      SqlDataAdapter adapter = new SqlDataAdapter(cmd);
      adapter.FillLoadOption = LoadOption.OverwriteChanges;
      adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
      DataTable table = new DataTable();
      adapter.Fill(table);
      return table;
    }


    public DataTable ExecuteProcedure(string procedureName, List<SqlParameter> parameters)
    {
      using (SqlConnection connection = GetConnection())
      {
        SqlCommand cmd = CreateProcedureCommand(procedureName, parameters, connection);
        return ExecuteCommand(cmd);
      }
    }

    public object ExecuteProcedureScalar(string procedureName, List<SqlParameter> parameters)
    {
      using (SqlConnection connection = GetConnection())
      {
        SqlCommand cmd = CreateProcedureCommand(procedureName, parameters, connection);
        return cmd.ExecuteScalar();
      }
    }

    public int ExecuteProcedureNonQuery(string procedureName, List<SqlParameter> parameters)
    {
      using (SqlConnection connection = GetConnection())
      {
        SqlCommand cmd = CreateProcedureCommand(procedureName, parameters, connection);
        return cmd.ExecuteNonQuery();
      }
    }

    private SqlCommand CreateProcedureCommand(string procedureName, List<SqlParameter> parameters, SqlConnection connection)
    {
      SqlCommand cmd = connection.CreateCommand();
      cmd.CommandType = CommandType.StoredProcedure;
      cmd.CommandText = procedureName;
      if ((parameters != null) && (parameters.Count > 0))
      {
        cmd.Parameters.AddRange(parameters.ToArray());
      }
      return cmd;
    }

  }
}
