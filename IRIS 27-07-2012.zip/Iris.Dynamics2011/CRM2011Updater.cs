﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Iris.Runtime.Model.DisignSuport;
using Iris.Runtime.Model.Operations.NetworkOperations;
using Iris.Runtime.NetworkOperations;
using Iris.Runtime.Model.BaseObjects;
using Iris.Interfaces;
using Iris.WebOperations;
using System.ComponentModel;
using Iris.Runtime.Model.PropertyEditors;
using System.Drawing.Design;
using System.Net;
using CRMFramework2011;
using System.ServiceModel.Description;
using System.Data;
using System.Threading.Tasks;
using Iris.Runtime.Model.Entities;
using System.Threading;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Windows.Forms;

namespace Iris.Dynamics2011
{
  [Serializable]
  [OperationCategory("Operações de Controle", "Dynamics Updater 2011")]
  public class CRM2011Updater : NetworkOperation, IBaseWebServiceOperation
  {
    public CRM2011Updater(Structure aStructure, string aName)
      : base(aStructure, aName)
    {
      SetInputs("Entrada", "Configs");
      applyInserts = true;
      applyUpdates = true;
      applyDeletes = false;
      MaxErrors = 0;
    }

    protected void SetupConfigs()
    {
      if (GetInput("Configs") != null)
      {
        IScalarVar configVar = GetInput("Configs") as IScalarVar;
        if (configVar != null)
        {
          if (configVar.RawValue is WsConfigs)
          {
            WsConfigs configs = (WsConfigs)configVar.RawValue;
            configs.SetupOperation(this);
          }
        }
      }
    }

    [Browsable(false)]
    public IResultSet Entrada
    {
      get
      {
        IOperation input = GetInput("Entrada");
        if (input == null)
          throw new Exception("Resultset de entrada não atribuído");
        else
          return (IResultSet)input.EntityValue;
      }
    }

    public string Organization { get; set; }

    public int MaxErrors { get; set; }

    private string resultColumn;
    [Editor(typeof(CBOColumnSelectorEditor), typeof(UITypeEditor))]
    [DisplayName("Coluna Resultado")]
    public string ResultColumn
    {
      get { return resultColumn; }
      set { resultColumn = value; }
    }

    private bool applyUpdates;

    public bool ApplyUpdates
    {
      get { return applyUpdates; }
      set { applyUpdates = value; }
    }

    private bool applyInserts;

    public bool ApplyInserts
    {
      get { return applyInserts; }
      set { applyInserts = value; }
    }

    private bool applyDeletes;

    public bool ApplyDeletes
    {
      get { return applyDeletes; }
      set { applyDeletes = value; }
    }

    private string entityName;

    public string EntityName
    {
      get { return entityName; }
      set { entityName = value; }
    }

    protected string wsdlLocation;
    [Category("Web Service"), DisplayName("Servidor"), Description("Endereço do servidor do CRM 2011")]
    public string WsdlLocation
    {
      get { return wsdlLocation; }
      set
      {
        if (wsdlLocation != value)
        {
          wsdlLocation = value;
          Reset();
        }
      }
    }

    public override void Reset()
    {
      base.Reset();
      exceptionList = new ConcurrentQueue<string>();
    }


    [NonSerialized, DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    private ServiceManager service;
    [NonSerialized, DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    private ConcurrentQueue<String> exceptionList;

    public bool MultiThread { get; set; }
    private int errorCount;

    protected override IEntity doExecute()
    {
      exceptionList = new ConcurrentQueue<string>();
      DataView view = Entrada.View;
      errorCount = 0;
      insertCount = 0;
      updateCount = 0;
      try
      {
        if (ApplyUpdates)
        {
          ProcessProxyList(view.ToProxyList(EntityName, DataViewRowState.ModifiedCurrent));
        }
        if (ApplyInserts)
        {
          ProcessProxyList(view.ToProxyList(EntityName, DataViewRowState.Added));
        }
      }
      finally
      {
        Structure.AddToLog(string.Format("{0} registros inseridos com sucesso", insertCount), this);
        Structure.AddToLog(string.Format("{0} registros atualizados com sucesso", updateCount), this);

        if (exceptionList.Count > 0)
        {
          int localErrorCount = 0;
          string item = "";
          while (exceptionList.TryDequeue(out item))
          {
            Structure.AddToErrorLog(item, this);
            localErrorCount++;
          }
          Structure.AddToErrorLog(String.Format("Total de erros:", localErrorCount), this);
        }

        exceptionList = new ConcurrentQueue<string>();
      }
      return null;
    }

    private int batchSize;

    public int BatchSize
    {
      get { return batchSize; }
      set { batchSize = value; }
    }

    private void ProcessProxyList(List<DynamicEntityProxy> list)
    {
      int recordCount = list.Count;
      int firstRecord = 0;
      int batchNumber = 0;
      int batchSize = BatchSize;

      if (batchSize == 0)
        batchSize = recordCount;

      int batchCount;

      if (BatchSize != 0)
        batchCount = Convert.ToInt32(Math.Ceiling((decimal)(recordCount) / (decimal)(BatchSize)));
      else
        batchCount = 1;


      Stopwatch sw = new Stopwatch();


      for (firstRecord = 0; firstRecord < recordCount; firstRecord += batchSize)
      {
        batchNumber++;


        int lastRecord = firstRecord + batchSize;
        if (lastRecord > recordCount)
          lastRecord = recordCount;

        InitializeService();

        sw.Start();
        if (MultiThread)
        {
          Parallel.For(firstRecord, lastRecord, (i) => UpdateProxy(list[i]));
        }
        else
        {
          for (int i = firstRecord; i < lastRecord; i++)
          {
            UpdateProxy(list[i]);
          }
        }
        sw.Stop();

        int recordsProccessed = lastRecord - firstRecord;
        Structure.AddToLog(string.Format("Lote {0} de {1} -- {2} Registros processados -- Tempo: {3}",
          batchNumber, batchCount, recordsProccessed, sw.Elapsed), this);
        sw.Reset();
        Application.DoEvents();
      }
    }

    private void InitializeService()
    {

      if (service != null)
        service.Dispose();

      SetupConfigs();
      ClientCredentials serviceCredentials = new ClientCredentials();
      serviceCredentials.Windows.ClientCredential = WebCredentials;
      service = new ServiceManager(Organization, serviceCredentials, WsdlLocation);

    }

    [NonSerialized]
    private int insertCount;
    [NonSerialized]
    private int updateCount;

    private void UpdateProxy(DynamicEntityProxy proxy)
    {
      try
      {
        service.UpdateProxy(proxy);
        if (proxy.Insert)
          insertCount++;
        else
          updateCount++;
      }
      catch (Exception ex)
      {
        lock (this)
        {
          AddToLog(proxy, ex);

          errorCount++;

          if (errorCount <= MaxErrors)
            InitializeService();
          else
            throw;
        }
      }
    }

    private void AddToLog(DynamicEntityProxy proxy, Exception ex)
    {
      StringBuilder builder = new StringBuilder();
      GetFullExceptionMessage(ex, builder);

      if (!string.IsNullOrEmpty(ResultColumn))
      {
        string logColumnValue = Convert.ToString(proxy[ResultColumn]);
        exceptionList.Enqueue(string.Format("{2} ---> [{0}] = {1}", ResultColumn, logColumnValue, builder.ToString()));
      }
      else
        exceptionList.Enqueue(builder.ToString());
    }




    private void GetFullExceptionMessage(Exception ex, StringBuilder sb)
    {
      sb.AppendFormat("{0};", ex.Message);
      if (ex.InnerException != null)
        GetFullExceptionMessage(ex.InnerException, sb);
    }


    #region Explicit interface
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    NetworkCredential IBaseWebServiceOperation.Credentials { get { return null; } set { } }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    System.Reflection.MethodInfo IBaseWebServiceOperation.Method { get { return null; } set { } }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    System.Reflection.MethodInfo[] IBaseWebServiceOperation.MethodList
    {
      get
      {
        return null;
      }
    }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    int IBaseWebServiceOperation.Port
    { get { return 0; } set { } }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    string IBaseWebServiceOperation.ProxyServer
    { get { return null; } set { } }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    bool IBaseWebServiceOperation.UseDefaultCredentials
    { get { return true; } set { } }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    bool IBaseWebServiceOperation.UseWebProxy
    { get { return false; } set { } }

    Type IBaseWebServiceOperation.GetRemoteType(string typeName)
    {
      return null;
    }

    #endregion
  }
}
