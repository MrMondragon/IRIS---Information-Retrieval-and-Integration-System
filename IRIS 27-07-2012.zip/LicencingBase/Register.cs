﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using Databridge.Engine.Criptography;
using System.Management;

namespace LicencingBase
{
  public static class Register
  {
    private static Cube GetCertificate()
    {
      Cube cub = Cube.GetDefaultLongCube();
      string valueName = cub.UnRComp("Certificate", cub.ResizeKey(Register.GetMacAddress(), 1)[0]);
      Certificate = LoadObjectDef<Cube>(valueName);
      return Certificate;
    }

    private static Cube certificate;
    public static Cube Certificate
    {
      get
      {
        if (certificate == null)
          certificate = GetCertificate();

        if (certificate != null)
          return certificate;
        else
          return Cube.GetDefaultLongCube();
      }
      set { certificate = value; }
    }

    private static string RegistryPath
    {
      get
      {
        string path = Registry.CurrentUser + "\\Software\\DataBridge";
        return path;
      }
    }

    public static void SaveObject(object obj, string valueName)
    {
      string key = Certificate.UnRComp(valueName);

      string enObj = Certificate.EnvelopeObject(obj, key);
      Registry.SetValue(RegistryPath, valueName, enObj);
    }


    public static T LoadObject<T>(string valueName)
    {
      string key = Certificate.UnRComp(valueName);
      
      string enObj = Convert.ToString(Registry.GetValue(RegistryPath, valueName, ""));
      if (string.IsNullOrEmpty(enObj))
        return default(T);

      return Certificate.UnEnvelopeObject<T>(enObj, key);
    }

    /// <summary>
    /// Grava um objeto criptografado no registro usando o certificado padrão
    /// </summary>
    /// <param name="obj"></param>
    /// <param name="valueName"></param>
    public static void SaveObjectDef(object obj, string valueName)
    {
      Cube cert = Cube.GetDefaultLongCube();
      string enObj = cert.EncryptObject(obj, valueName);
      Registry.SetValue(RegistryPath, valueName, enObj);
    }

    /// <summary>
    /// Carrega um objeto criptografado do registro usando o certificado padrão
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="valueName"></param>
    /// <returns></returns>
    public static T LoadObjectDef<T>(string valueName)
    {
      string enObj = Convert.ToString(Registry.GetValue(RegistryPath, valueName, ""));
      if (string.IsNullOrEmpty(enObj))
        return default(T);
      Cube cert = Cube.GetDefaultLongCube();
      return cert.DecryptObject<T>(enObj, valueName);
    }

    /// <summary>
    /// Grava um objeto criptografado no registro
    /// </summary>
    /// <param name="obj"></param>
    /// <param name="valueName"></param>
    public static void SaveEnveloped(object obj, string valueName)
    {
      string envelope = Certificate.EnvelopeObject(obj, valueName);
      Registry.SetValue(RegistryPath, valueName, envelope);
    }

    /// <summary>
    /// Carrega um objeto criptografado do registro
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="valueName"></param>
    /// <returns></returns>
    public static T LoadEnvelope<T>(string valueName)
    {
      string enObj = Convert.ToString(Registry.GetValue(RegistryPath, valueName, ""));
      if (string.IsNullOrEmpty(enObj))
        return default(T);

      return Certificate.UnEnvelopeObject<T>(enObj, valueName);
    }

    /// <summary>
    /// Grava um valor string criptografado no registro
    /// </summary>
    /// <param name="str"></param>
    /// <param name="valueName"></param>
    public static void SaveValue(string str, string valueName)
    {
      string enStr = Certificate.CloseWithKey(str, valueName);
      Registry.SetValue(RegistryPath, valueName, str);
    }

    /// <summary>
    /// Obtem um valor string criptografado do registro
    /// </summary>
    /// <param name="valueName"></param>
    /// <returns></returns>
    public static string LoadValue(string valueName)
    {
      string enStr = Convert.ToString(Registry.GetValue(RegistryPath, valueName, ""));
      string str = Certificate.OpenWithKey(enStr, valueName);
      return str;
    }


    

    public static string GetMacAddress()
    {
      ManagementClass oMClass = new ManagementClass("Win32_NetworkAdapterConfiguration");

      ManagementObjectCollection colMObj = oMClass.GetInstances();
      Dictionary<string, int> addresses = new Dictionary<string, int>();
      int max = 0;

      foreach (ManagementObject objMO in colMObj)
      {
        string macAddress = Convert.ToString(objMO["MacAddress"]);
        if (!string.IsNullOrEmpty(macAddress))
        {
          if (!addresses.ContainsKey(macAddress))
          {
            PropertyDataCollection pdc = objMO.Properties;
            int propCount = 0;
            foreach (PropertyData item in pdc)
            {
              if (objMO[item.Name] != null)
                propCount++;
            }

            addresses[macAddress] = propCount; ;

            if (propCount > max)
              max = propCount;
          }
        }
      }

      if (addresses.Count > 0)
      {
        List<string> selectedAddresses = addresses.Where(x => x.Value == max).Select(x => x.Key).ToList();
        //List<string> selectedAddresses = addresses.Select(x => x.Key).ToList();
        string mac = selectedAddresses[0];

        if (selectedAddresses.Count > 1)
        {
          for (int i = 1; i < selectedAddresses.Count; i++)
          {
            string[] bas = mac.Split(':');
            string[] address = selectedAddresses[i].Split(':');
            mac = "";
            for (int j = 0; j < bas.Length; j++)
            {
              int b1 = Convert.ToInt32(bas[j], 16);
              int b2 = Convert.ToInt32(address[j], 16);

              int b = (b1 + b2) % 256;

              mac += System.Convert.ToString(b, 16).PadLeft(2, '0') + ":";
            }
            mac = mac.TrimEnd(':');
          }
        }

        mac = mac.ToUpper();

        return mac += ":" + selectedAddresses.Count.ToString().PadLeft(2, '0');
      }
      else
      {
        return "";
      }

    }

    public static string GetMainValueName()
    {
      string[] parts = GetMacAddress().Split(':');

      int[] values = parts.Select(x => Certificate.StringToInt(x, 3)).ToArray();

      string number = "";

      for (int i = 0; i < values.Length; i++)
      {
        number += values[i].ToString();
      }

      Big big = new Big(number);

      string key = Certificate.BigToString(big, 7);

      return key;
    }

  }
}
