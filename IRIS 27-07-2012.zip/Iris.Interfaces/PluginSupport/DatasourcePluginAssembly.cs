﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hermes.Designer.PluginEngine
{
  [AttributeUsage(AttributeTargets.Assembly)]
  public class DatasourcePluginAssembly:Attribute
  {
  }
}
