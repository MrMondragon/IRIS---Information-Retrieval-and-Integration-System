using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Iris.Designer.Plugins
{

  [AttributeUsage(AttributeTargets.Assembly)]
  public class ToolBarPluginAssembly : Attribute
  {
  }

}
