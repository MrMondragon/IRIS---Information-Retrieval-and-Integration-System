using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.Designer.PluginSupport
{
  [AttributeUsage(AttributeTargets.Assembly)]
  public class BehaviorPluginAssembly : Attribute
  {
  }
}
