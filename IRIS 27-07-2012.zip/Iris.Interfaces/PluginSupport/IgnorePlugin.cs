using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.Designer.Plugins
{
  [AttributeUsage(AttributeTargets.Class)]
  public class IgnorePlugin: Attribute
  {
  }
}
