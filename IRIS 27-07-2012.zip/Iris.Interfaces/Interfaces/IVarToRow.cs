﻿using System;
using Iris.Interfaces;
namespace Iris.Runtime.Model.Operations.VarOperations
{
  public interface IVarToRow
  {
    IResultSet Saida { get; }
  }
}
