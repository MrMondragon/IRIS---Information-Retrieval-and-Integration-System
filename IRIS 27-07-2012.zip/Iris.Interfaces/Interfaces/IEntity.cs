﻿using System;
namespace Iris.Interfaces
{
  public interface IEntity: IOperation
  {
  }
}
