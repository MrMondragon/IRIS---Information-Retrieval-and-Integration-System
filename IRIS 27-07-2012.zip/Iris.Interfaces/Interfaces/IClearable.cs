using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.Runtime.Model.PropertyEditors.Interfaces
{
  public interface IClearable
  {
    void Clear();
  }
}
