﻿using System;
namespace Iris.DataGenerator
{
  public interface IListLookup
  {
    System.Collections.Generic.List<string> Values { get; set; }
  }
}
