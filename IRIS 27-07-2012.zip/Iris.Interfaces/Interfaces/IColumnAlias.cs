﻿using System;
using System.Collections.Generic;


namespace Iris.Interfaces
{
  public interface IColumnAlias
  {
    Dictionary<string, string> Items { get; set; }
  }
}
