﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;
using Microsoft.Win32;
using System.Security.Principal;
using System.Windows.Forms;
using Databridge.Engine.Criptography;
using LicencingBase;

namespace LicenceManager
{
  public static class Manager
  {
    #region Mac Address

    public static string GetMacAddress()
    {
      ManagementClass oMClass = new ManagementClass("Win32_NetworkAdapterConfiguration");

      ManagementObjectCollection colMObj = oMClass.GetInstances();
      Dictionary<string, int> addresses = new Dictionary<string, int>();
      int max = 0;

      foreach (ManagementObject objMO in colMObj)
      {
        string macAddress = Convert.ToString(objMO["MacAddress"]);
        if (!string.IsNullOrEmpty(macAddress))
        {
          if (!addresses.ContainsKey(macAddress))
          {
            PropertyDataCollection pdc = objMO.Properties;
            int propCount = 0;
            foreach (PropertyData item in pdc)
            {
              if (objMO[item.Name] != null)
                propCount++;
            }

            addresses[macAddress] = propCount; ;

            if (propCount > max)
              max = propCount;
          }
        }
      }

      if (addresses.Count > 0)
      {
        List<string> selectedAddresses = addresses.Where(x => x.Value == max).Select(x => x.Key).ToList();
        //List<string> selectedAddresses = addresses.Select(x => x.Key).ToList();
        string mac = selectedAddresses[0];

        if (selectedAddresses.Count > 1)
        {
          for (int i = 1; i < selectedAddresses.Count; i++)
          {
            string[] bas = mac.Split(':');
            string[] address = selectedAddresses[i].Split(':');
            mac = "";
            for (int j = 0; j < bas.Length; j++)
            {
              int b1 = Convert.ToInt32(bas[j], 16);
              int b2 = Convert.ToInt32(address[j], 16);

              int b = (b1 + b2) % 256;

              mac += System.Convert.ToString(b, 16).PadLeft(2, '0') + ":";
            }
            mac = mac.TrimEnd(':');
          }
        }

        mac = mac.ToUpper();

        return mac += ":" + selectedAddresses.Count.ToString().PadLeft(2, '0');
      }
      else
      {
        return "";
      }

    }

    #endregion

    #region User and Computer Information

    public static string GetCurrentUser()
    {
      return WindowsIdentity.GetCurrent().Name;
    }

    public static string GetComputerName()
    {
      return SystemInformation.ComputerName;
    }

    #endregion

    #region Certificate

    internal static void InstallCertificate(Cube certificate)
    {
      Cube cub = Cube.GetDefaultLongCube();
      string valueName = cub.UnRComp("Certificate", cub.ResizeKey(Register.GetMacAddress(), 1)[0]);

      Register.Certificate = null;
      Register.SaveObjectDef(certificate, valueName);
      Register.Certificate = certificate;
    }

  

    #endregion

    #region Token

    internal static string GetToken()
    {
      DateTime date = DateTime.Now;
      return GetToken(date);
    }

    internal static string GetToken(DateTime date)
    {
      
      int dd = date.Day;
      int mm = date.Month;
      int yy = Convert.ToInt32(date.Year.ToString().Substring(2));
      int hh = date.Hour;
      int nn = date.Minute;
      int ss = date.Second;

      string d = Register.Certificate.IntToString(dd, 0);
      string m = Register.Certificate.IntToString(mm, 0);
      string y = Register.Certificate.IntToString(yy, 0);
      string h = Register.Certificate.IntToString(hh, 0);
      string n = Register.Certificate.IntToString(nn, 0);
      string s = Register.Certificate.IntToString(ss, 0);

      string word = Register.Certificate.GetWordAt(dd, mm, yy, hh, nn, ss, 6);

      string token = d + m + y + h + n + s + word;

      string checkSum = Register.Certificate.ResizeKey(token, 1);
      token += checkSum;

      token = Register.Certificate.RComp(token);

      return token;
    }



    #endregion

 

  }
}
