﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Management;
using Databridge.Engine.Criptography;
using System.Security.Principal;
using LicenceManager.br.com.databridge.services;
using LicenceManager.br.com.databridge.services1;
using LicencingBase;

namespace LicenceManager
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e)
    {
      textBox1.Text = Register.GetMacAddress();
    }

    private void button2_Click(object sender, EventArgs e)
    {
      //Cube cube = Cube.GetDefaultShortCube();
      //StringBuilder sb = new StringBuilder();
      //for (int i = 0; i < 9; i++)
      //{
      //  string str = cube.GetRandomText(4);
      //  sb.AppendFormat("{0}-", str);
      //}

      //string key = string.Format("{{{0}}}", sb.ToString().TrimEnd('-')).ToUpper();

      //textBox1.Text = string.Format("{0} >> {1}", key, key.Length);
      Random rnd = new Random();


      string key = Register.Certificate.GetRandomText(rnd.Next(12));
      string value = Register.Certificate.GetRandomText(rnd.Next(512)+512);

      textBox1.Text = string.Format("[{0}] -> {1}", key, value);
    }

    private void button3_Click(object sender, EventArgs e)
    {
      Cube cub = new Cube("Teste");
      Manager.InstallCertificate(cub);
    }
  }
}
