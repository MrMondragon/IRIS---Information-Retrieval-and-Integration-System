using System;
using System.Collections.Generic;
using System.Text;
using Iris.Runtime.Model.BaseObjects;
using System.Drawing;
using MindFusion.Diagramming.WinForms;

namespace Iris.Designer.VisualObjects
{
  [Serializable]
  public class PersistenceStructure: IDisposable
  {
    public PersistenceStructure(Structure aStructure, FlowChart surface, string aOutputPath)
    {
      structure = aStructure;
      operations = new List<PersistenceOperation>();
      foreach (Table table in surface.Tables)
        operations.Add(new PersistenceOperation((VisualOperation)table));
      
      links = new List<PersistenceLink>();
      foreach (Arrow arrow in surface.Arrows)
        links.Add(new PersistenceLink(arrow));

      outputPath = aOutputPath;
    }

    internal string outputPath;
    private Structure structure;

    public Structure Structure
    {
      get { return structure; }
      set { structure = value; }
    }
    internal List<PersistenceOperation> operations;
    internal List<PersistenceLink> links;

    #region IDisposable Members

    public void Dispose()
    {
      structure = null;
      operations.Clear();
      links.Clear();
    }

    #endregion
  }

  [Serializable]
  class PersistenceOperation
  {
    public PersistenceOperation(VisualOperation oper)
    {
      name = oper.Operation.Name;
      rect = oper.BoundingRect;
    }

    internal string name;
    internal RectangleF rect;
    internal float x
    {
      get { return rect.Left; }
    }
    internal float y
    {
      get { return rect.Top; }
    }
  }

  [Serializable]
  class PersistenceLink
  {
    public PersistenceLink(Arrow arrow)
    {
      link = (VisualLink)arrow.Tag;
      penColor = arrow.PenColor;
      segmentCount = arrow.SegmentCount;
      points = new List<PointF>();
      for (int i = 0; i < arrow.ControlPoints.Count; i++)
      {
        points.Add(arrow.ControlPoints[i]);
      }
    }
    internal VisualLink link;
    internal Color penColor;
    internal List<PointF> points;
    internal short segmentCount;
  }

}
