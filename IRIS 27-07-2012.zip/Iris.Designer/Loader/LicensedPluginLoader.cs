﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LicencingBase;
using System.Windows.Forms;


namespace Iris.Designer.Loader
{
  internal class LicensedPluginLoader
  {
    internal string[] GetLicensedPlugins()
    {
      string valueName = Register.GetMainValueName();
      List<string>  plugins = Register.LoadObject<List<string>>(valueName);
      string plugsDir = Application.StartupPath + "\\Plugins\\";
      return plugins.Select(x => plugsDir + x).ToArray();
    }
  }
}
