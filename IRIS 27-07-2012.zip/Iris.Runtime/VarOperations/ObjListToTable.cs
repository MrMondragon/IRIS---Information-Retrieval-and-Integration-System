﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Iris.Runtime.Model.DisignSuport;
using Iris.Runtime.Model.Operations.VarOperations;
using Iris.Runtime.Model.BaseObjects;
using Iris.Interfaces;
using System.ComponentModel;
using System.Collections;
using System.Data;
using System.Reflection;

namespace Iris.Runtime.VarOperations
{
  [Serializable]
  [OperationCategory("Operações de Variável", "Object List to Table")]
  public class ObjListToTable: BaseVarOperation
  {
    public ObjListToTable(Structure aStructure, string aName)
      : base(aStructure, aName)
    {
      SetInputs("Entrada");
    }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    private IScalarVar Entrada
    {
      get
      {
        return GetInput(0) as IScalarVar;
      }
    }

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    private IResultSet Saida
    {
      get
      {
        return GetOutput(0) as IResultSet;
      }
    }

    protected override IEntity doExecute()
    {
      if (Entrada == null)
        throw new Exception("Entrada inválida");

      if (Saida == null)
        throw new Exception("Saída inválida");

      DataTable table = new DataTable(Saida.Name);
      Saida.Table = table;

      IEnumerable list = Entrada.RawValue as IEnumerable;
      if (list != null)
      {
        IEnumerable<object> objList = list.Cast<object>();
        if (objList.Count() > 0)
        {
          Dictionary<string, PropertyInfo> properties = BuildTable(objList.First());
          table.BeginLoadData();
          foreach (object obj in objList)
          {
            table.LoadDataRow(ObjectToItemArray(obj, properties), true);
          }
        }

        Structure.AddToLog(String.Format("{0} registros carregados", objList.Count()), this);
      }

      return (IEntity) Saida;
    }

    private object[] ObjectToItemArray(object obj, Dictionary<string, PropertyInfo> properties)
    {
      object[] itemArray = new object[properties.Count];
      int i = 0;
      foreach (KeyValuePair<string, PropertyInfo> item in properties)
      {
        itemArray[i] = item.Value.GetValue(obj, null);
        i++;
      }

      return itemArray;
    }

    private Dictionary<string, PropertyInfo> BuildTable(object obj)
    {
      PropertyInfo[] props= obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.FlattenHierarchy);
      Dictionary<string, PropertyInfo> properties = new Dictionary<string, PropertyInfo>();
      foreach (PropertyInfo pi in props)
      {
        string typeName = pi.PropertyType.ToString();
        Type propType = pi.PropertyType;
        bool required = true;
        if (typeName.Contains("Nullable"))
        {
          propType = propType.GetGenericArguments().First();
          required = false;
        }

        DataColumn col = new DataColumn(pi.Name, propType);
        col.AllowDBNull = !required;
        properties[pi.Name] = pi;
        Saida.Table.Columns.Add(col);
      }
      return properties;
    }

  }
}
