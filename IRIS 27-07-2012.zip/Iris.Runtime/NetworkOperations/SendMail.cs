﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Iris.Runtime.Model.BaseObjects;
using Iris.Runtime.Model.DisignSuport;
using System.Net.Mail;
using Iris.Runtime.Model.Operations.NetworkOperations;
using Databridge.Interfaces;
using System.ComponentModel;
using Iris.PropertyEditors;
using System.Drawing.Design;
using Databridge.Engine.Parsers;

namespace Iris.Runtime.NetworkOperations
{
  [Serializable]
  [OperationCategory("Operações de Controle", "Envio de E-Mail")]
  public class SendMail : NetworkOperation, IScriptedObject
  {
    public SendMail(Structure aStructure, string aName)
      : base(aStructure, aName)
    {

    }

    private int port;

    public int Port
    {
      get { return port; }
      set { port = value; }
    }

    private string to;

    public string To
    {
      get { return to; }
      set { to = value; }
    }

    private string from;

    public string From
    {
      get { return from; }
      set { from = value; }
    }

    private string subject;

    public string Subject
    {
      get { return subject; }
      set { subject = value; }
    }

    private string body;
    [Editor(typeof(ScriptEditor), typeof(UITypeEditor))]
    public string Body
    {
      get { return body; }
      set { body = value; }
    }

    private string smtp;

    public string Smtp
    {
      get { return smtp; }
      set { smtp = value; }
    }

    private string GetmergedBody()
    {
      MergerParser parser = MergerParser.GetParser();
      string mergedbody = parser.Parse(body, Structure.GetContext()).MergedText;
      return mergedbody;      
    }

    /*message.From = new System.Net.Mail.MailAddress("From@online.microsoft.com");
message.Body = "This is the message body";
System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient("yoursmtphost");
smtp.Send(message);*/

    private bool useDefaulCredentials;

    public bool UseDefaulCredentials
    {
      get { return useDefaulCredentials; }
      set { useDefaulCredentials = value; }
    }

    protected override Interfaces.IEntity doExecute()
    {
      MailMessage msg = new MailMessage();
      msg.From = new MailAddress(From);

      List<string> list = to.Split(',', ';').Select(x=> x.Trim()).ToList();
      foreach (string item in list)
      {
        msg.To.Add(item);
      }

      msg.Subject = Subject;

      msg.Body = GetmergedBody();

      SmtpClient client = new SmtpClient(Smtp, Port);

      client.UseDefaultCredentials = UseDefaulCredentials;
      if (!UseDefaulCredentials)
        client.Credentials = WebCredentials;

      client.Send(msg);

      Structure.AddToLog(String.Format("Mensagem enviada para {0}", To), this);

      return null;
    }


    #region IScriptedObject Members
    [Browsable(false)]
    public string Script
    {
      get
      {
        return Body;
      }
      set
      {
        Body = value;
      }
    }

    [Browsable(false)]
    public string Language
    {
      get { return "Text"; }
    }

    [Browsable(false)]
    IExecutionContext IScriptedObject.Context
    {
      get { return Structure.GetContext(); }
    }
    #endregion

  }
}
