using System;
using System.Collections.Generic;
using System.Text;

namespace Iris.DataOperations.ColumnBasedOperations
{
  public enum AggregateType
  {
    Sum,
    Avg,
    Min,
    Max,
    Count,
    StDev,
    Var
  }
}
